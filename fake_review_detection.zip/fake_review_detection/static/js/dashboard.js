(function () {
  "use strict"; const RG = window.RG, $ = (id) => document.getElementById(id);
  document.addEventListener("DOMContentLoaded", async function () {
    try {
      const d = await RG.api("/api/stats"), a = d.analyses;
      $("kpiTotal").textContent = a.total; $("kpiFake").textContent = a.total ? Math.round(a.fake / a.total * 100) + "%" : "-";
      $("kpiLangs").textContent = a.by_language.length || "-";
      if (!a.total) {
        const empty = '<div class="empty">' + RG.icon("scan") + '<p>You have not checked any reviews yet.</p><a class="btn sm" href="/single">Check your first review</a></div>';
        $("chartVerdict").innerHTML = empty; $("chartDays").innerHTML = '<div class="muted small">Appears after your first check.</div>';
        $("chartPlatform").innerHTML = $("chartLanguage").innerHTML = '<div class="muted small">Appears after your first check.</div>'; return;
      }
      RG.donut($("chartVerdict"), a.genuine, a.fake);
      const max = Math.max.apply(null, a.by_day.map((x) => x.total)) || 1;
      $("chartDays").innerHTML = '<div class="spark" role="img" aria-label="Reviews checked per day">' + a.by_day.map((x) => '<div style="height:' + Math.max(4, x.total / max * 100) + '%" title="' + RG.esc(x.day) + ": " + x.total + ' reviews"></div>').join("") + "</div>" +
        '<div class="small muted" style="margin-top:6px">' + RG.esc(a.by_day[0].day) + " to " + RG.esc(a.by_day[a.by_day.length - 1].day) + " (hover a bar for the number)" + "</div>";
      RG.bars($("chartPlatform"), a.by_platform); RG.bars($("chartLanguage"), a.by_language);
    } catch (e) { RG.toast(e.message, "error"); }
    try {
      const p = await RG.api("/api/platforms");
      $("platformStrip").innerHTML = p.platforms.filter((x) => x.name !== "Other").map((x) =>
        '<div class="plat"><span class="logo p-' + RG.esc(x.name.toLowerCase()) + '">' + RG.esc(x.name.charAt(0)) + '</span><div><strong>' + RG.esc(x.name) + '</strong><div class="small muted">' + RG.esc(x.status) + "</div></div></div>").join("");
    } catch (e) { /* non-critical */ }
  });
})();
