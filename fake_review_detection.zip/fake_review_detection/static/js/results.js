(function () {
  "use strict"; const RG = window.RG, $ = (id) => document.getElementById(id), PAGE = 50; let offset = 0;
  const qs = () => { const p = new URLSearchParams({ limit: PAGE, offset }); [["fPlatform", "platform"], ["fLabel", "label"], ["fLang", "language"]].forEach((x) => { if ($(x[0]).value) p.set(x[1], $(x[0]).value); }); return p.toString(); };
  const row = (i) => "<tr><td class='small'>" + RG.esc(RG.fmtDate(i.created_at)) + "</td><td class='cell-text'>" + RG.esc(i.review_text.length > 160 ? i.review_text.slice(0, 160) + "..." : i.review_text) +
    "<div class='meta'>" + RG.esc(i.language) + " · tone: " + RG.esc(String(i.sentiment || "-").toLowerCase()) + " · " + RG.esc(i.source_type.replace("batch_", "from a list/file: ").replace("single", "single check")) + "</div></td><td>" + RG.verdictBadge(i.prediction) +
    "</td><td>" + RG.esc(RG.sure(i.confidence, i.low_confidence)) + "<div class='meta'>" + Math.round(i.confidence * 100) + "%</div></td><td>" + RG.esc(i.platform) + "</td></tr>";
  async function load(reset) {
    if (reset) offset = 0; RG.show($("errorBox"), false);
    try {
      const d = await RG.api("/api/history?" + qs());       const html = d.items.map(row).join("");
      if (reset) $("resBody").innerHTML = html || '<tr><td colspan="5"><div class="empty">' + RG.icon("list") + "<p><strong>Nothing to show yet.</strong></p><p class=\"small\">Checked reviews appear here. Try <a href=\"/single\">checking one review</a>, or change the filters above.</p></div></td></tr>"; else $("resBody").insertAdjacentHTML("beforeend", html);
      RG.show($("moreBtn"), d.items.length === PAGE);
    } catch (e) { $("errorBox").textContent = e.message; RG.show($("errorBox"), true); }
  }
  document.addEventListener("DOMContentLoaded", function () {
    ["fPlatform", "fLabel", "fLang"].forEach((id) => $(id).addEventListener("change", () => load(true)));
    $("moreBtn").addEventListener("click", () => { offset += PAGE; load(false); });
    $("clearAll").addEventListener("click", async function () { if (!confirm("Delete all your past checks? This cannot be undone.")) return; try { const d = await RG.api("/api/history", { method: "DELETE" }); RG.toast("Deleted " + d.removed + " past checks."); load(true); } catch (e) { RG.toast(e.message, "error"); } });
    load(true);
  });
})();
