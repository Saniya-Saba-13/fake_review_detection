(function () {
  "use strict"; const RG = window.RG, $ = (id) => document.getElementById(id); let last = [], fileMode = false;
  function mode(file) {
    fileMode = file; RG.show($("paneText"), !file); RG.show($("paneFile"), file);
    $("tabPasteBtn").classList.toggle("on", !file); $("tabFileBtn").classList.toggle("on", file);
    $("tabPasteBtn").setAttribute("aria-selected", String(!file)); $("tabFileBtn").setAttribute("aria-selected", String(file));
  }
  let filter = "all";
  function applyFilter() {
    document.querySelectorAll("#bulkBody tr").forEach((tr) => { tr.classList.toggle("hidden", filter !== "all" && tr.dataset.v !== filter); });
    document.querySelectorAll("[data-filter]").forEach((b) => b.classList.toggle("on", b.dataset.filter === filter));
  }
  function why(r) {
    const fake = r.label === "Likely Fake", main = fake ? r.top_fake_terms : r.top_genuine_terms, bits = [];
    if (main && main.length) bits.push((fake ? "Suspicious" : "Genuine") + " words: " + main.slice(0, 3).map((t) => "“" + RG.esc(t.term) + "”").join(", "));
    (r.signals || []).slice(0, 2).forEach((x) => bits.push(RG.esc(x.name)));
    return bits.length ? bits.join("<br>") : '<span class="muted small">Few familiar words, close to a guess</span>';
  }
  function render(d) {
    last = d.results; filter = "all";
    $("bulkBody").innerHTML = d.results.map((r, i) => {
      const text = r.review.length > 200 ? r.review.slice(0, 200) + "..." : r.review;
      return '<tr data-v="' + (r.label === "Likely Fake" ? "fake" : "genuine") + '"><td>' + RG.esc(r.row || i + 1) + '</td><td class="cell-text">' + RG.esc(text) + '<div class="meta">' + RG.esc(r.platform) + (r.product ? " · " + RG.esc(r.product) : "") + " · " + RG.esc(r.language.language) + " · tone: " + RG.esc(String(r.sentiment.label).toLowerCase()) + "</div></td><td>" + RG.verdictBadge(r.label) +
        "</td><td>" + RG.esc(RG.sure(r.confidence, r.low_confidence)) + '<div class="meta">' + Math.round(r.confidence * 100) + "%</div></td><td class=\"small\">" + why(r) + "</td></tr>";
    }).join("");
    const n = d.results.length, f = d.summary.fake, g = d.summary.genuine;
    $("batchSentence").innerHTML = "<strong>" + n + " review" + (n === 1 ? "" : "s") + " checked:</strong> " + g + " look" + (g === 1 ? "s" : "") + " genuine and " + f + " look" + (f === 1 ? "s" : "") + " suspicious.";
    RG.donut($("batchChart"), d.summary.genuine, d.summary.fake);
    const agg = (fn) => { const m = {}; d.results.forEach((r) => { const k = fn(r); m[k] = m[k] || { name: k, total: 0, fake: 0 }; m[k].total++; if (r.label === "Likely Fake") m[k].fake++; }); return Object.values(m); };
    $("batchBars").innerHTML = '<div><div class="label">By language</div><div id="bl"></div></div><div><div class="label">By tone of the review</div><div id="bs"></div></div>';
    RG.bars($("bl"), agg((r) => r.language.language)); RG.bars($("bs"), agg((r) => r.sentiment.label));
    if (d.skipped && d.skipped.length) { $("skippedBox").innerHTML = RG.icon("alert") + "<div><strong>" + d.summary.skipped + " row(s) could not be checked and were left out:</strong><ul style='margin:6px 0 0 18px;padding:0'>" + d.skipped.slice(0, 8).map((s) => "<li>Row " + RG.esc(s.row) + ": " + RG.esc(s.reason) + "</li>").join("") + "</ul></div>"; RG.show($("skippedBox"), true); } else RG.show($("skippedBox"), false);
    applyFilter(); RG.show($("resultsBox"), true); $("resultsBox").scrollIntoView({ behavior: "smooth", block: "start" });
  }
  async function run() {
    RG.show($("errorBox"), false); $("bulkBtn").disabled = true; RG.show($("loading"), true);
    try {
      let d;
      if (fileMode) {
        const f = $("fileInput").files[0]; if (!f) throw new Error("Please choose an Excel (.xlsx) or CSV (.csv) file first.");
        const n = f.name.toLowerCase(); if (!(n.endsWith(".csv") || n.endsWith(".xlsx"))) throw new Error("This file type is not supported. Please use an Excel (.xlsx) or CSV (.csv) file.");
        if (f.size > RG.limits.maxUploadMb * 1048576) throw new Error("The file is too big. Please keep it under " + RG.limits.maxUploadMb + " MB.");
        const fd = new FormData(); fd.append("file", f); d = await RG.api("/api/predict-bulk", { method: "POST", form: fd });
      } else {
        const lines = $("bulkInput").value.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
        if (!lines.length) throw new Error("Please paste at least one review first (one review per line)."); if (lines.length > RG.limits.maxBulk) throw new Error("That is too many reviews at once. Please paste at most " + RG.limits.maxBulk + ".");
        d = await RG.api("/api/predict-bulk", { method: "POST", json: { reviews: lines } });
      }
      render(d);
    } catch (e) { RG.show($("resultsBox"), false); $("errorBox").textContent = e.message; RG.show($("errorBox"), true); }
    finally { $("bulkBtn").disabled = false; RG.show($("loading"), false); }
  }
  document.addEventListener("DOMContentLoaded", function () {
    $("tabPasteBtn").addEventListener("click", () => mode(false)); $("tabFileBtn").addEventListener("click", () => mode(true)); $("bulkBtn").addEventListener("click", run);
    $("bulkClear").addEventListener("click", () => { $("bulkInput").value = ""; $("fileInput").value = ""; $("bulkBody").innerHTML = ""; last = []; RG.show($("resultsBox"), false); RG.show($("errorBox"), false); RG.donut($("batchChart"), 0, 0); $("batchBars").innerHTML = ""; });
    document.querySelectorAll("[data-filter]").forEach((b) => b.addEventListener("click", () => { filter = b.dataset.filter; applyFilter(); }));
    $("downloadCsv").addEventListener("click", function () {
      const rows = [["row", "review", "platform", "language", "prediction", "confidence", "fake_probability", "sentiment", "low_confidence", "model_version"]];
      last.forEach((r) => rows.push([r.row, r.review, r.platform, r.language.language, r.label, r.confidence, r.fake_probability, r.sentiment.label, r.low_confidence, r.model_version]));
      const url = URL.createObjectURL(new Blob(["\ufeff" + rows.map((r) => r.map(RG.csvCell).join(",")).join("\r\n")], { type: "text/csv;charset=utf-8" }));
      const a = document.createElement("a"); a.href = url; a.download = "reviewguard_answers.csv"; a.click(); URL.revokeObjectURL(url);
    });
  });
})();
