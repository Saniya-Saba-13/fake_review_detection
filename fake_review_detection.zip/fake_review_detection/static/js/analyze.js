(function () {
  "use strict"; const RG = window.RG, $ = (id) => document.getElementById(id), max = RG.limits.maxChars;
  const input = $("review");
  const product = () => { const v = $("product").value; return v === "Other (not listed)" ? $("productOther").value.trim() : v; };
  const syncProduct = () => { const o = $("product").value === "Other (not listed)"; RG.show($("productOther"), o); if (!o) $("productOther").value = ""; };
  const count = () => { $("charCount").textContent = input.value.length + " / " + max; };
  async function run() {
    RG.show($("errorBox"), false); const text = input.value.trim();
    if (!text) { $("errorBox").textContent = "Please paste a review into the box first (step 1)."; RG.show($("errorBox"), true); return; }
    if (text.length > max) { $("errorBox").textContent = "This review is too long. Please keep it under " + max + " characters."; RG.show($("errorBox"), true); return; }
    $("analyzeBtn").disabled = true; RG.show($("loading"), true);
    try {
      const body = { review: text, title: $("title").value.trim() }; if ($("rating").value) body.rating = Number($("rating").value); if (product()) body.product = product();
      const d = await RG.api("/api/predict", { method: "POST", json: body });
      $("resultArea").innerHTML = RG.resultCard(d.result, text);
      if (d.result.detected_rating && !$("rating").value) $("rating").value = String(Math.round(d.result.detected_rating)); $("resultArea").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) { $("errorBox").textContent = e.message; RG.show($("errorBox"), true); }
    finally { $("analyzeBtn").disabled = false; RG.show($("loading"), false); }
  }
  document.addEventListener("DOMContentLoaded", function () {
    input.addEventListener("input", count); input.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") run(); });
    $("analyzeBtn").addEventListener("click", run); $("product").addEventListener("change", syncProduct);
    $("clearBtn").addEventListener("click", () => { input.value = ""; $("title").value = ""; $("rating").value = ""; $("product").value = ""; syncProduct(); count(); RG.show($("errorBox"), false); input.focus(); });
    document.querySelectorAll(".ex").forEach((b) => b.addEventListener("click", function () {
      input.value = b.dataset.text; count(); RG.show($("errorBox"), false);
    }));
    $("resultArea").addEventListener("click", function (e) { if (e.target.closest("[data-again]")) { input.value = ""; $("title").value = ""; $("rating").value = ""; $("product").value = ""; syncProduct(); count(); input.scrollIntoView({ behavior: "smooth", block: "center" }); input.focus(); } });
    count();
  });
})();
