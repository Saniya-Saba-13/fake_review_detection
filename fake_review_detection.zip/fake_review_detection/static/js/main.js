/* ReviewGuard shared helpers (window.RG). All dynamic text is escaped before insertion. */
(function (root) {
  "use strict";
  const RG = root.RG = {};
  RG.limits = root.RG_LIMITS || {};
  RG.esc = (v) => String(v === null || v === undefined ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  RG.pct = (x) => (x * 100).toFixed(1) + "%";
  RG.icon = (n) => '<svg class="icon" aria-hidden="true"><use href="#i-' + n + '"/></svg>';
  RG.show = (el, on) => el.classList.toggle("hidden", !on);

  RG.toast = function (msg, kind) {
    const box = document.getElementById("toasts"); if (!box) return;
    const el = document.createElement("div"); el.className = "toast " + (kind || ""); el.textContent = msg; box.appendChild(el);
    setTimeout(() => el.remove(), kind === "error" ? 7000 : 3500);
  };

  async function parse(res) {
    let data = null; try { data = await res.json(); } catch (e) { /* not JSON */ }
    if (!res.ok || !data || data.ok === false) { const err = new Error((data && data.error) || "Request failed (HTTP " + res.status + ")."); err.data = data; err.status = res.status; throw err; }
    return data;
  }
  RG.api = async function (url, opts) {
    opts = opts || {}; const init = { method: opts.method || "GET", headers: {} };
    if (opts.json !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(opts.json); }
    if (opts.form) init.body = opts.form;
    let res; try { res = await fetch(url, init); } catch (e) { throw new Error("Could not reach the server. Is `python app.py` still running?"); }
    return parse(res);
  };

  RG.refreshModelPill = async function () {
    const pill = document.getElementById("pill-model"); if (!pill) return null;
    try {
      const h = await RG.api("/api/health"); const dot = pill.querySelector(".dot"), txt = pill.querySelector("span:last-child");
      if (h.model_loaded) { dot.className = "dot ok"; txt.textContent = "Ready to check"; pill.title = "Checker " + h.model_version + (h.model_is_demo ? ": trained on made-up practice reviews" : ": ready to use"); }
      else { dot.className = "dot err"; txt.textContent = "Not set up yet"; pill.title = "The checker has not been trained yet"; }
      const b = document.getElementById("demo-banner"); if (b) b.classList.toggle("hidden", !(h.model_loaded && h.model_is_demo));
      return h;
    } catch (e) { pill.querySelector(".dot").className = "dot err"; pill.querySelector("span:last-child").textContent = "App not running"; return null; }
  };

  RG.platformLogo = (name) => '<span class="logo p-' + RG.esc(String(name).toLowerCase()) + '" style="width:30px;height:30px;border-radius:9px;display:inline-grid;place-items:center;color:#fff;font-weight:800;font-size:.8rem">' + RG.esc(String(name).charAt(0)) + "</span>";
  RG.verdictBadge = (label) => '<span class="badge ' + (label === "Likely Fake" ? "rose" : "green") + '">' + (label === "Likely Fake" ? "Looks suspicious" : "Looks genuine") + "</span>";
  RG.langBadge = (l) => '<span class="badge violet">' + RG.icon("globe") + RG.esc(l) + "</span>";
  RG.sentBadge = (s) => '<span class="badge ' + ({ Positive: "green", Negative: "orange", Mixed: "amber" }[s] || "") + '">' + RG.esc(s) + "</span>";

  RG.donut = function (el, genuine, fake) {
    const total = genuine + fake, g = total ? genuine / total * 100 : 0;
    const bg = total ? "conic-gradient(var(--emerald) 0 " + g + "%, var(--rose) " + g + "% 100%)" : "#E9E4F7";
    el.innerHTML = '<div class="donut-wrap"><div class="donut" style="background:' + bg + '"><div class="donut-hole">' + total + "<small>checked</small></div></div><div>" +
      '<div><span class="legend-dot" style="background:var(--emerald)"></span>Looks genuine: <strong>' + genuine + "</strong></div>" +
      '<div><span class="legend-dot" style="background:var(--rose)"></span>Looks suspicious: <strong>' + fake + "</strong></div></div></div>";
  };
  /* rows: [{name,total,fake}] -> horizontal bars: rose part = suspicious share */
  RG.bars = function (el, rows, emptyText) {
    if (!rows || !rows.length) { el.innerHTML = '<div class="muted small">' + RG.esc(emptyText || "No data yet.") + "</div>"; return; }
    el.innerHTML = '<div class="bars">' + rows.map((r) => {
      const share = r.total ? (r.fake || 0) / r.total : 0;
      return '<div class="bar-row"><span>' + RG.esc(r.name) + '</span><div class="meter" title="' + RG.pct(share) + ' suspicious"><span style="width:' + Math.round(share * 100) + '%"></span></div><span class="small muted">' + r.total + " checked · " + Math.round(share * 100) + "% suspicious</span></div>";
    }).join("") + "</div>";
  };

  RG.chips = (terms, cls) => (!terms || !terms.length) ? '<span class="muted small">none</span>' : terms.map((t) => '<span class="term ' + cls + '" title="relative strength ' + RG.esc(t.strength) + '">' + RG.esc(t.term) + "</span>").join("");

  /* "How sure": words instead of numbers first */
  RG.sure = (c, low) => low || c < 0.70 ? "Not very sure" : (c >= 0.85 ? "Very sure" : "Fairly sure");
  RG.verdictOf = function (r) {
    const fake = r.label === "Likely Fake", low = !!r.low_confidence;
    return { fake: fake, low: low, cls: low ? "unsure" : (fake ? "fake" : "genuine"),
      icon: low ? "info" : (fake ? "alert" : "check"),
      title: fake ? (low ? "Might be suspicious" : "This review looks suspicious") : (low ? "Might be genuine" : "This review looks genuine"),
      sub: (fake ? "It has writing patterns often seen in fake or paid reviews." : "It reads like a normal customer review.") + (low ? " The tool is not very sure, so do not rely on this answer." : "") };
  };
  /* the short "why": built from the structured fields, not from the long technical sentence */
  RG.reasons = function (r, text) {
    const out = [], fake = r.label === "Likely Fake", words = (a) => (a || []).filter((t) => /[\p{L}\p{N}]/u.test(t.term)), main = words(fake ? r.top_fake_terms : r.top_genuine_terms), other = words(fake ? r.top_genuine_terms : r.top_fake_terms);
    const q = (a, n) => a.slice(0, n).map((t) => "“" + RG.esc(t.term) + "”").join(", ");
    if (main && main.length) out.push("Words that pointed towards <strong>" + (fake ? "suspicious" : "genuine") + "</strong>: " + q(main, 4) + ".");
    if (other && other.length) out.push("Words that pointed the other way (" + (fake ? "genuine" : "suspicious") + "): " + q(other, 3) + ".");
    (r.signals || []).slice(0, 3).forEach((s) => out.push("<strong>" + RG.esc(s.name) + ".</strong> " + RG.esc(s.detail)));
    if (r.language_note) out.unshift(RG.esc(r.language_note));
    if (text && text.trim().split(/\s+/).length < 4) out.push("The review is very short, so the tool has little to go on.");
    if (!out.length || (!(main && main.length) && !(other && other.length))) out.push("Few of the words were familiar to the tool, so this answer is close to a guess.");
    return out;
  };
  RG.nextSteps = (v) => v.fake
    ? ["Do not rely on this review alone. Read a few other reviews of the same product.", "Look for a “verified purchase” tag and for real details (size, how it was used, photos)."]
    : ["Nothing unusual was found in the writing.", "Still read a few other reviews: a fake can be written to look natural."];

  RG.productBox = function (r) {
    const pc = r.product_check; if (!pc || !pc.product) return "";
    const cls = pc.level === "mismatch" ? "warn" : "info", ttl = { match: "Matches the product", weak_match: "Could fit the product", mismatch: "Does not seem to match the product", unknown: "Product check" }[pc.level] || "Product check";
    return '<div class="alert ' + cls + '">' + RG.icon("info") + "<div><strong>" + RG.esc(ttl) + " (" + RG.esc(pc.product) + ")</strong><br>" + RG.esc(pc.message || "") +
      (pc.raised_suspicion ? " This raised the suspicion score a little (the writing alone gave " + Math.round(pc.model_probability * 100) + "% suspicious)." : "") + "</div></div>";
  };
  RG.langBox = function (r) {
    const lc = r.language_check; if (!lc || !lc.applied) return "";
    const warn = lc.pattern_details && lc.pattern_details.length;
    return '<div class="alert ' + (warn ? "warn" : "info") + '">' + RG.icon("info") + "<div><strong>Hinglish / Hindi check</strong><br>" +
      (warn ? lc.pattern_details.map(RG.esc).join(" ") + " This raised the suspicion score a little. " : "No stuffing or stacked hype wording found. ") +
      "The tool is less certain for Hinglish than for English because it has seen far fewer Hinglish examples.</div></div>";
  };
  RG.resultCard = function (r, text) {
    const v = RG.verdictOf(r), fp = (r.fake_probability * 100).toFixed(0), gp = (r.genuine_probability * 100).toFixed(0), conf = Math.round(r.confidence * 100);
    const lang = r.language || {}, se = r.sentiment || {};
    const sig = (r.signals && r.signals.length) ? r.signals.map((s) => '<div class="signal"><strong>' + RG.esc(s.name) + '</strong><div class="small muted">' + RG.esc(s.detail) + "</div></div>").join("") : '<span class="muted small">None noticed.</span>';
    return '<div class="card answer">' +
      '<div class="banner ' + v.cls + '"><span class="big-ico">' + RG.icon(v.icon) + "</span><div><h2>" + RG.esc(v.title) + "</h2><p>" + RG.esc(v.sub) + "</p></div></div>" +
      '<div class="answer-body">' +
      ((r.pasted_removed && r.pasted_removed.length) ? '<div class="alert info">' + RG.icon("info") + "<div>Ignored text the shopping site added when you copied: " + r.pasted_removed.map(RG.esc).join(", ") + ". Only the customer's own words were checked.</div></div>" : "") + RG.productBox(r) + RG.langBox(r) +
            '<div class="sure"><div class="sure-word"><span>How sure is the tool?</span><span>' + RG.sure(r.confidence, r.low_confidence) + " (" + conf + "%)</span></div>" +
      '<div class="meter" role="img" aria-label="Confidence ' + conf + ' percent"><span style="width:' + conf + '%"></span></div></div>' +
      "<div><h3>Why did it say this?</h3><ul class=\"reasons\">" + RG.reasons(r, text).map((x) => "<li>" + x + "</li>").join("") + "</ul></div>" +
      '<div class="todo"><strong>What should I do now?</strong><ul>' + RG.nextSteps(v).map((x) => "<li>" + RG.esc(x) + "</li>").join("") + "</ul></div>" +
      '<div class="row"><button class="btn" type="button" data-again="1">Check another review</button></div>' +
      '<details><summary>Show more details</summary><div class="inner">' +
        '<div class="row">' + RG.langBadge(lang.language || "Unknown") + (lang.confidence === "low" ? '<span class="badge amber">language not certain</span>' : "") + '<span class="badge">Tone: ' + RG.esc(se.label || "-") + "</span>" + '<span class="badge orange">' + RG.icon("bag") + RG.esc(r.platform || "Other") + '</span>' + (r.product ? '<span class="badge">' + RG.esc(r.product) + '</span>' : "") + '<span class="badge" title="Version of the checker used">checker ' + RG.esc(r.model_version) + "</span></div>" +
        '<div><div class="small muted" style="margin-bottom:4px">Genuine ' + gp + "% · Suspicious " + fp + '%</div><div class="meter split2"><span style="width:' + gp + '%"></span><span style="width:' + fp + '%"></span></div></div>' +
        '<div class="grid g2"><div><div class="label muted">Words pushing towards suspicious</div>' + RG.chips(r.top_fake_terms, "fake") + '</div><div><div class="label muted">Words pushing towards genuine</div>' + RG.chips(r.top_genuine_terms, "genuine") + "</div></div>" +
        '<div><div class="label">Writing patterns noticed (hints only)</div>' + sig + "</div>" +
        '<div class="small muted">Positive words: ' + RG.esc((se.positive_terms || []).join(", ") || "none") + " · Negative words: " + RG.esc((se.negative_terms || []).join(", ") || "none") + ". The tone is shown for context only and is not used to decide if a review is fake.</div>" +
        '<div class="small muted"><strong>Full technical explanation:</strong> ' + RG.esc(r.explanation) + "</div>" +
      "</div></details>" +
      '<div class="small muted">' + RG.esc(r.disclaimer) + "</div></div></div>";
  };

  RG.csvCell = function (v) { let s = String(v === null || v === undefined ? "" : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  RG.fmtDate = (iso) => { const d = new Date(iso); return isNaN(d) ? iso : d.toLocaleString(); };

  document.addEventListener("DOMContentLoaded", function () {
    const btn = document.getElementById("menuBtn"), scrim = document.getElementById("scrim");
    const set = (o) => { document.body.classList.toggle("nav-open", o); if (btn) btn.setAttribute("aria-expanded", String(o)); };
    if (btn) btn.addEventListener("click", () => set(!document.body.classList.contains("nav-open")));
    if (scrim) scrim.addEventListener("click", () => set(false));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") set(false); });
    RG.refreshModelPill();
  });
})(window);
