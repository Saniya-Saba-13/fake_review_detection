# Real-data training (what was done and what it means)

Source files used: Amazon.com customer reviews (2 exports, overlapping), Multilingual Meesho reviews, and a Flipkart-style review file (~363k rows).
**None of them contains fake/genuine labels.** Myntra data was not available, so Myntra is not in the training data.

## How labels were made (rules, `prepare_real_data.py`, label_method `weak_rules_v1`)
* Suspicious: copy-pasted text (same text under >=3 different Flipkart-style products, or repeated on Amazon/Meesho) or hype-wording 5-star reviews.
* Presumed genuine: unique text matching no rule. Samples are matched to the suspicious ones by language, length and star group so the model cannot learn "short = fake" or "negative = fake".
* Reviews that cannot be called either way are left out. The labelling sheet reviews are kept out of training.

## What the scores mean
* Test scores (about 78% accuracy, F1 0.77) measure how well the model reproduces those rules. They are **not** proof it finds real fake reviews.
* Check on 3,410 real reviews it never saw: about 9% flagged suspicious (Amazon 1%, Meesho 1%, Flipkart-style 19%). Before (practice model) it flagged 51-71% of real Meesho/Flipkart-style reviews.

## Languages
* English: ~11,700 training rows. Hindi: none. Hinglish: only 12.
* The model therefore answers "Not very sure" for Hindi, Hinglish and mixed reviews instead of guessing.

## Next step to make it real
1. Open `data/labelling_sheet.csv` (460 reviews, 124 Hindi/Hinglish/mixed). Fill `label` with genuine / fake (leave blank if unsure).
2. Save as CSV (UTF-8), add a `label_method` column or use `--label-method manual_annotation`, then:
```
python build_dataset.py --ingest data\labelling_sheet_filled.csv --label-method manual_annotation
python train_model.py --data-mode real
```
3. Do NOT run `build_dataset.py --demo` (it only adds synthetic rows).

## Pasting a review from a shopping site
Copy a review from Meesho, Myntra, Flipkart or Amazon and paste it exactly as copied. Lines the site adds (date, "Verified Purchase",
"Certified Buyer, Mumbai", "Helpful for 12", "Read more", "5.0 out of 5 stars") are ignored, and the platform and star rating are
picked up automatically when the pasted text shows them.

## Teaching it more Hinglish
Hinglish needs examples labelled by a person. `data/hinglish_labelling_sheet.csv` has 445 Hindi / Hinglish / mixed reviews (Meesho and Flipkart).
Fill the `label` column (genuine / fake, empty if unsure), then run:
```
python add_labels.py "C:\path\hinglish_labelling_sheet_filled.csv"
```
It stores the labels, retrains and prints the new score per language. Aim for 200+ fake and 200+ genuine Hinglish labels; until then the tool says "Not very sure" for Hinglish.
