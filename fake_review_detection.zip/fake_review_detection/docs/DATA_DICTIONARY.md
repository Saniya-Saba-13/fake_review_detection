# Data dictionary (master_reviews.csv)

| column | meaning |
|---|---|
| `review_id` | Unique id made as <source_dataset>:<row id>. Taken from the source's own id when it has one. |
| `platform_name` | Amazon, Flipkart, Myntra, Meesho or Other. Kept exactly as the source says. |
| `marketplace_domain` | Domain taken from the product URL (for example amazon.com or amazon.in). Empty if the source has no URL. |
| `record_type` | product_review (review of a product), app_review (review of the shopping app) or fake_benchmark (research set with authenticity labels). |
| `product_id` | Product id from the source (for example the Amazon ASIN read from the URL). Empty if not available. |
| `product_name` | Product title from the source. |
| `product_category` | Category from the source, if given. |
| `product_brand` | Brand from the source, if given. |
| `review_title` | Review headline. Empty when the source has none. |
| `review_text` | ORIGINAL review text (whitespace tidied only). Hindi, Hinglish and emojis are preserved. |
| `text_normalized` | Lower-cased copy with Devanagari and common Hinglish spelling variants normalised. Used for duplicate detection and models; review_text is never overwritten. |
| `review_text_translated` | Always empty here. No translation is performed; if you add translations, keep them in this column. |
| `rating` | Star rating 1 to 5 as given. |
| `review_date` | ISO date (YYYY-MM-DD) when the source date could be read, otherwise empty. |
| `verified_purchase` | True / False only when the source says so; empty otherwise. NOT an authenticity label. |
| `helpful_votes` | Number of helpful votes if given. |
| `reviewer_id` | Salted hash of the reviewer name. Empty when the source only has a placeholder name. |
| `product_price` | Price as a number (digits only) if the source has one; currency symbol was not readable in some files. |
| `seller_information` | Seller, only if the source has it. |
| `review_language` | English, Hindi, Hinglish, Mixed or Unknown, detected from the text by lexicon and script (approximate). |
| `source_sentiment_label` | Sentiment label that came with the source (not computed here). Not an authenticity label. |
| `authenticity_label` | genuine, fake or unknown. 'unknown' for every source that does not provide human or platform labels. |
| `label_source` | Where the authenticity label came from (source id and method). Empty when unknown. |
| `source_dataset` | Id of the dataset in data_collection/sources.json. |
| `source_url` | Product page URL from the source when present. |
| `dup_text_count` | How many records on the same platform have exactly the same normalised text (including this one). |
| `near_dup_group_id` | Reviews with the same words in any order, or the same first 80 characters, share a group id. Flagged, not deleted. |
| `split` | train / validation / test (70/15/15), assigned per near_dup_group_id so near-identical reviews never leak across splits. |
