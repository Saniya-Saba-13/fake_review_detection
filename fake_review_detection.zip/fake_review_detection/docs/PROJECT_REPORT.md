# AI-Powered Fake Product Review Detection System: Project Report

## 1. Abstract
Online shoppers rely on reviews, yet some reviews are paid, promotional or machine-generated. This project builds a
text-classification system that estimates whether a product review is *likely genuine* or *likely fake*. Reviews are
cleaned, converted to TF-IDF features (unigrams and bigrams) and classified by a linear model. Logistic Regression,
Multinomial Naive Bayes and a calibrated Linear SVM are compared on a validation split; the best one (by F1 on the fake
class, ties broken by ROC-AUC) is evaluated once on a held-out test split and saved with Joblib. A Flask web application loads
the saved model and returns, for each review, a prediction, an estimated confidence, the words that influenced it and
cautionary notes. Single reviews, pasted batches and CSV uploads are supported. The system never claims certainty: every
output is labelled an estimate. The bundled dataset is synthetic and for demonstration only; real labelled data can be
dropped in without code changes.

## 2. Problem statement
Customers trust ratings and reviews when buying online, but fake reviews can mislead them towards poor products. Manually
checking reviews does not scale. Build a system that analyses review text and estimates how likely each review is to be
fake, explains the estimate, and communicates its uncertainty, without treating sentiment or unusual wording as proof.

## 3. Objectives
1. Build a reproducible pipeline: load, clean, split, vectorise, train, compare, evaluate, save.
2. Compare three classical algorithms using validation metrics and avoid data leakage.
3. Report honest metrics (precision, recall, F1, ROC-AUC, confusion matrix), not accuracy alone.
4. Serve instant predictions from a saved model through a Flask API and responsive web dashboard.
5. Explain each prediction (influential terms, surface-pattern hints) and show a disclaimer.
6. Support bulk analysis with validated CSV upload.
7. Keep demonstration data clearly separated from real evaluation.

## 4. Existing vs proposed system
| | Existing practice | Proposed system |
|---|---|---|
| Detection | Manual reading, user "helpful" votes, platform-internal moderation (not visible to shoppers) | Automatic text-based estimate for any pasted or uploaded review |
| Transparency | Mostly none | Confidence, influential terms, caveats |
| Scale | Slow for humans | Hundreds of reviews per request |
| Risk | Missed fakes, or honest reviews removed unfairly | Estimates flagged as such; low-confidence cases marked; meant to assist a human |

## 5. System architecture
```
 Browser (Bootstrap + JS)
     │  fetch() JSON / multipart CSV
     ▼
 Flask app.py ── validation (type, size, length, columns, rating range) ── history store (in memory)
     │
     ▼
 predict.py (FakeReviewPredictor)
     │ clean_text() → TF-IDF transform → classifier.predict_proba → term contributions
     ▼
 models/fake_review_model.joblib  ◄── created once by train_model.py
 models/metrics.json              ◄── read by the Model Performance page
```

## 6. Workflow diagram
```mermaid
flowchart TD
  A[Labelled CSV] --> B[Load + clean: missing, duplicates, conflicts]
  B --> C[Stratified split 70/15/15]
  C --> D[Fit TF-IDF + classifier on TRAIN only]
  D --> E[Compare 3 algorithms on VALIDATION]
  E --> F[Select best by F1 fake class]
  F --> G[Evaluate once on TEST]
  G --> H[Save model.joblib + metrics.json + charts]
  H --> I[Flask loads saved model]
  I --> J[User review / CSV]
  J --> K[Prediction + confidence + explanation + disclaimer]
```

## 7. Optional real-world integration architecture
```
Authorised source (official marketplace/seller API, or a review export you are entitled to use)
   → scheduled batch job or queue
   → validation + clean_text
   → model service (this predictor, behind an internal API)
   → score + explanation stored with the review ID
   → moderation queue (human review) / seller dashboard / "review quality" badge
   → feedback labels from moderators → periodic retraining
```
Rules: use only permitted APIs or data you have rights to; no scraping against terms of service; no bypassing
authentication; keep a human in the loop; monitor drift and false-positive rates; follow privacy law for reviewer data.
This project does **not** implement any live marketplace integration.

## 8. Advantages
* Fast, lightweight, runs on a laptop with no GPU.
* Transparent linear models with per-term explanations.
* Leakage-aware evaluation and honest reporting of limits.
* Works offline on user text and CSV files; clean separation of ML, API, UI and tests.
* Dataset-agnostic: swap in real data without changing code.

## 9. Limitations
* **Bundled data is synthetic**: metrics on it do not predict real-world performance.
* Text-only: ignores reviewer history, timing bursts, verified purchase, IP/device and review-network signals that real
  platforms use.
* Bag-of-words ignores deeper semantics and context; sophisticated LLM-written fakes can evade it.
* Public datasets often label machine-generated text, which differs from paid human fake reviews; models may not transfer.
* Labels in the real world are noisy; some "genuine" labels are wrong.
* Probabilities are only approximately calibrated; thresholds should be tuned to the cost of mistakes.
* Possible bias: writing style, dialect or non-native English may be wrongly flagged.

## 10. Future enhancements
Reviewer and temporal features; near-duplicate detection across products; transformer embeddings (BERT) with the same
evaluation protocol; probability calibration checks and threshold tuning per use-case; SHAP/LIME explanations; active
learning from moderator feedback; multilingual and Hinglish support; persistent database and user accounts; model
monitoring and drift alerts; Docker deployment; fairness audits.

## 11. Interview explanation (60-second version)
"I built a Flask web app that estimates whether a product review is likely fake. Reviews are cleaned and turned into TF-IDF
vectors. I split the data before fitting anything to avoid leakage, compared Logistic Regression, Naive Bayes and a calibrated
Linear SVM on a validation set using F1 for the fake class, then evaluated the winner once on a test set. The pipeline is
saved with Joblib so the website loads it instantly. Each prediction comes with a confidence score, the terms that drove it
(weight times TF-IDF value) and a disclaimer, because text alone cannot prove fraud. The shipped dataset is synthetic, so I
report its metrics as a pipeline check only and documented how to retrain on real labelled data."

## 12. Viva questions and answers
1. **What does TF-IDF do?** It weights a term by how often it appears in a review (TF) and down-weights terms common in
   many reviews (IDF), so distinctive words matter more than words like "the".
2. **Why 1-2 grams?** Phrases such as "highly recommend" or "five stars" carry more signal than single words.
3. **Why compare three models?** They are fast linear baselines with different assumptions: LR (discriminative, probabilistic),
   NB (generative, word-count independence), SVM (max-margin). Validation results, not preference, choose the model.
4. **Why is accuracy not enough?** With 90% genuine reviews, predicting "genuine" always gives 90% accuracy and catches no
   fake review. Precision, recall, F1 and ROC-AUC expose this.
5. **Precision vs recall here?** Precision: of reviews flagged fake, how many truly are (matters to avoid accusing honest
   reviewers). Recall: how many fake reviews we catch. F1 balances them.
6. **What is ROC-AUC?** The probability that a random fake review scores higher than a random genuine one; threshold-independent.
7. **What is data leakage and how did you avoid it?** Information from validation/test data influencing training. I
   de-duplicate first, split before fitting, fit TF-IDF only on training data inside a Pipeline, select on validation and
   touch the test set once.
8. **Why remove duplicates before splitting?** Otherwise the same text can appear in train and test and inflate scores.
9. **Why does the SVM need calibration?** LinearSVC outputs margins, not probabilities; `CalibratedClassifierCV` maps them to
   probabilities so a confidence score is meaningful.
10. **How are explanations computed?** For linear models: TF-IDF value of each term times its coefficient (for NB, the
    log-probability ratio). Positive pushes to fake, negative to genuine. They show associations, not causes.
11. **Can sentiment prove a review is fake?** No. Genuine reviews can be extreme or enthusiastic, and fake ones can be
    balanced. The app says so explicitly.
12. **What does the confidence score mean?** The model's estimated probability for the predicted class. It is not a guarantee;
    values under 60% are flagged as low confidence.
13. **How does the site avoid retraining?** `train_model.py` saves the Pipeline with Joblib; Flask loads it once, lazily.
14. **Why is the dataset a problem?** The shipped one is synthetic template text with deliberate noise, so its scores
    only prove the code runs. Real evaluation needs real labelled data.
15. **How would you handle class imbalance?** `class_weight="balanced"`, stratified splits, F1/PR-AUC for selection, threshold tuning,
    possibly resampling.
16. **What are the security measures?** Input type/length validation, upload size/type checks, HTML escaping in the UI, CSV
    formula-injection guard on export, JSON errors, no execution of uploaded content.
17. **How would you deploy it?** Gunicorn/Waitress behind a reverse proxy, Docker image, model versioning, logging, health
    endpoint (`/health`), persistent DB instead of in-memory history.
18. **How would you improve it?** Reviewer/time features, transformer embeddings, calibration, SHAP, human feedback loop.
19. **Ethical concerns?** False positives harm honest customers and sellers; therefore estimates, disclaimers and human review.
20. **Why Joblib rather than Pickle?** Joblib handles large NumPy arrays efficiently and is the scikit-learn recommended
    persistence tool; both share the same trust and version-compatibility caveats (only load files you created, with the same library versions).
