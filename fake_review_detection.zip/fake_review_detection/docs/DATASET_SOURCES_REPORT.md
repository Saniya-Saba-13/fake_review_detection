# Dataset research report (research date: 2026-11-01)

**Read this first.** The research workspace could open many dataset *pages* but could not download from Kaggle, Hugging Face, Zenodo or Mendeley.
So nothing below was downloaded by me except the four files you supplied. Every number is marked with how it was checked:
`file` = counted in a file you supplied, `page` = read on the dataset page, `paper` = taken from a research paper, `no` = not checked.
Licences are what the page showed. Confirm the licence yourself before using any data.

## 1. Platform by platform: what is realistically available

| Platform | Product reviews (free, legal) | Size | Notes |
|---|---|---|---|
| **Flipkart** | Kaggle "Flipkart product customer reviews" (the file you supplied) | 363,239 rows, 307,661 after exact-duplicate removal (`file`) | Only source reaching 100k+. Product names and prices only. No dates, no verified flag, no reviewer ids. About 46% of rows repeat a text. English almost only (443 Hinglish rows). |
| **Amazon India** | Mendeley "amazon extraction dataset" ([link](https://data.mendeley.com/datasets/2pv6d8fz7y)) | 5,035 reviews (`page`) | Genuine Amazon India reviews but tiny, and only 3-5 star reviews. Licence not stated on the page. |
| | Amazon Reviews 2023, McAuley Lab ([link](https://huggingface.co/datasets/McAuley-Lab/Amazon-Reviews-2023)) | 570M+ reviews, 33 categories (`page`, via a mirror) | Huge, but global Amazon data (mostly amazon.com), **not Amazon India**. Download one category at a time. Check the dataset card for terms and the verified-purchase field. |
| | Your two "ARE CustomerReviews" files | 2,614 after merging (`file`) | **amazon.com (USA), not amazon.in.** Has a verified-purchase flag. |
| **Meesho** | Your "Multilingual Meesho Review Dataset" | 1,009 rows, 1,006 after cleaning (`file`) | Best Indian-language source you have: 64% English, 16% Hinglish, 9% mixed, 8% Hindi. Very small. |
| **Myntra** | **None found.** | 0 | I found no free public Myntra *product* review dataset. Only paid providers (e.g. [Bright Data](https://brightdata.com/products/insights/reviews-tracker/myntra), Actowiz) and scraper tools exist. Scrapers can break the platform's terms; I did not use or recommend them without a check. |

## 2. Product reviews vs shopping-app reviews (they are not the same)
* **ShoppingAppReviews, Mendeley v2** ([link](https://data.mendeley.com/datasets/chr5b94c6y), DOI 10.17632/chr5b94c6y.2): 751,500 English reviews of the **shopping apps** (Amazon, Flipkart, Meesho, Myntra and 8 more) from Google Play (`page`). Licence **CC BY-NC 4.0 (non-commercial)**. These review the app (delivery, crashes), not products. It is the only large source naming Myntra and Meesho, but it is not product-review data, so it is kept as `record_type = app_review` and should not be mixed into product-fraud training.

## 3. Hindi / Hinglish sources
* **Code-mixed e-commerce reviews, Mendeley** ([link](https://data.mendeley.com/datasets/xxprggbztd/1)): Roman Hindi, Roman Urdu and English e-commerce reviews with positive/negative/neutral sentiment. CC BY 4.0 (`page`). Record count not stated on the page. Good for Hinglish vocabulary; no fake labels.
* I did not find a free, large, labelled Hindi or Hinglish *fake* review dataset. Regional Indian languages other than Hindi: nothing verified.

## 4. Datasets with real fake / genuine labels (benchmarks)
| Dataset | Size | How labels were made | Access |
|---|---|---|---|
| Yelp NYC (Rayana and Akoglu) ([page](https://odds.cs.stonybrook.edu/?p=562)) | 359,052 reviews, about 36,900 filtered (fake) (`page`) | Yelp's own spam filter (imperfect) | The page says to email the authors |
| Ott et al. 2011 | 1,600 (800 + 800) (`paper`) | Paid crowd workers wrote the deceptive ones | Hotel reviews, English |
| DeRev (Fornaciari and Poesio) | 1,552 (776 + 776) (`paper`) | Writers who confessed to paid reviewing | Amazon books, English |
| Fake Reviews Dataset "OR/CG" (Salminen et al.) | not checked (`no`) | CG = machine-generated text, not human paid reviews | Kaggle; I could not open it |

None is Indian or Hindi. They are useful to learn general fake-review writing patterns in English, not Indian-platform fraud. The Zenodo "Amazon product reviews" set is labelled **mock** (simulated) by its author and is **not** real data: do not use it.

## 5. Records by authenticity label (what you have today)
All 311,281 processed records are **unknown** authenticity. Only Amazon (your v1/v2) carries a verified-purchase flag: 1,901 verified, 713 not verified. Verified-purchase is stored as its own column and is never converted into a label, and unverified is not treated as fake.

## 6. Honest limits
* The target of 100,000+ real reviews **per platform** is not achievable from free, legal sources: only Flipkart reaches it. Amazon India has about 5,000 free, Meesho about 1,000, Myntra none.
* No free source gives genuine/fake labels for Indian platforms. Realistic routes: label a sample by hand (see `data/labelling_sheet.csv`), partner with a platform, or buy data under a licence.
* Records from the Flipkart-style file contain broken characters (shown as `?`) that were already damaged in the source file. They could not be recovered.

## 7. How to collect everything accessible
```
python build_master_dataset.py list      # catalogue with licences and counts
python build_master_dataset.py fetch     # Kaggle CLI download (needs your own API key); prints manual steps for the rest
python build_master_dataset.py build     # one master CSV + one CSV per platform + reports
```
Outputs: `master/master_reviews.csv`, `master/{amazon,flipkart,myntra,meesho}_reviews.csv`, `master/reports/*.md`, `docs/DATA_DICTIONARY.md`.
