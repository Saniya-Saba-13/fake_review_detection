# Upgrade notes (original project -> multilingual ReviewGuard AI)

## Kept (still works as before)
* `python train_model.py`, `python app.py`, routes `/`, `/single`, `/bulk`, `/history`, `/performance`, `/about`, `/api/predict`, `/api/predict-bulk`, `/api/model-info`, `/api/history`, `/health`.
* Single and bulk analysis, per-word explanations, surface-pattern hints, disclaimers, CSV upload validation, input validation and error handling, history, performance page.
* `preprocessing.py`, `data_utils.py`, `generate_demo_data.py`, `data/sample_reviews.csv`, `data/sample_upload.csv` (original English files).
* Original tests for text cleaning / signals / dataset helpers (`tests/test_preprocessing.py`).

## Changed on purpose
* Models are now versioned folders (`models/versions/<v>/`, `models/active.json`) instead of one `fake_review_model.joblib`; retrain on the old data requires `python build_dataset.py --ingest data\sample_reviews.csv --label-method synthetic_template` (the old demo file has no label-method column).
* Prediction history moved from memory to SQLite, so it survives restarts.
* Bulk upload now also accepts `.xlsx`, a per-row `platform` column and an optional `title`.
* API result objects gained `display_label`, `language`, `sentiment`, `platform`, `model_version`, `model_is_demo`, `id` (existing fields kept).
* Old tests for the previous English-only training/API were replaced by tests of the new pipeline.

## Design decisions worth knowing
* **Platform and language are not model inputs.** They are metadata used for reporting; otherwise the model could learn "Hindi = fake" or "Meesho = genuine".
* **Per-language balancing** of the training data, and evaluation of false-positive rate per language.
* **Char n-gram TF-IDF** is the main answer to Hinglish spelling variation (accha / acha / achha) and works without translation.
* **Sentiment is a lexicon heuristic**, deliberately separate from the fake/genuine model, never used as evidence.
* **Synthetic demo data**: designed so that single words like "product" and short bland sentences are NOT class cues (earlier versions of the generator taught the model that short generic reviews are fake; a model trained on templates will still find other shortcuts). Treat all demo scores as a pipeline check only.
* **Transformers** are an optional, separate script because they need PyTorch, internet access and ideally a GPU, none of which were available when this was built.

## Not done / needs you
* Real labelled Hindi / Hinglish / platform data (see README "Bringing in real data").
* Running `train_transformer.py` and checking its first run.
* Any live marketplace integration (none is available to me; see README).
* A visual check of the interface in your browser.
