# Training on real data (guide)

The bundled data is synthetic, so the model cannot be trusted on real reviews until you train it on real, labelled reviews.

## Why this cannot be done by simply collecting reviews
* A scraped review has no fake/genuine label. The label has to come from somewhere trustworthy:
  1. a published dataset whose authors labelled it,
  2. reviews the platform itself removed as fake (moderator_removed), or
  3. your own manual annotation of a sample.
* Do not scrape Amazon, Flipkart, Meesho or Myntra against their terms. Use exports you are entitled to (your own seller/brand data), licensed or public datasets.

## Steps
1. Download a public labelled fake-review dataset on your own computer (check its licence). Search for:
   "fake reviews dataset OR CG" (English, labels OR = original, CG = computer generated), "deceptive opinion spam", or papers on Indian e-commerce reviews.
2. Save it as CSV/XLSX with columns: `review` (text), `label` (genuine/fake, OR/CG or 0/1), optional `platform`, `rating`, `collection_date`.
3. Open the app, go to **Training data**, choose the file, write how the labels were obtained (for example `published_dataset_<name>`), press **Add this file**.
4. Add Hindi / Hinglish examples too: label at least 200 reviews yourself (100 genuine, 100 fake) from Meesho / Flipkart reviews you may use, and add them the same way with label method `manual_annotation`.
5. Press **Train again**. With 200+ verified rows the tool stops using the practice data automatically.
6. Open **How accurate is it?** and check the per-language scores. If Hindi or Hinglish scores are much worse than English, add more Hindi / Hinglish examples.

## Tips for labelling by hand
Signals that suggest a paid or fake review: many reviews with near-identical wording, generic praise with no product detail, bursts of 5-star reviews on one day, brand-new accounts, reviewers who only review one seller. Only text can be used by this tool, so label using all the evidence you have, then give the tool just the text.
