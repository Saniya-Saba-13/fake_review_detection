"""Shared fixture: SYNTHETIC multilingual data ingested into a temporary database and one model trained ONCE into a temp folder
(never touches data/ or models/)."""
import random
import shutil
import tempfile
from pathlib import Path
from unittest import mock

import config
import db
import generate_multilingual_demo as gen
import train_model
from ingest import ingest_labelled
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB

_state = {}


def fast_candidates():
    """Two quick candidates keep the test-suite fast; the real list (four algorithms) is checked separately."""
    return [("Logistic Regression", lambda C: LogisticRegression(C=C, class_weight="balanced", max_iter=1000), [{"C": 2.0}]),
            ("Multinomial Naive Bayes", lambda alpha: MultinomialNB(alpha=alpha), [{"alpha": 0.5}])]


def make_demo_db(path, n_genuine=45, n_fake=22, seed=5):
    for platform, frame in gen.generate(n_genuine, n_fake, seed).items():
        csv = Path(path).parent / f"{platform.lower()}_t.csv"
        frame.to_csv(csv, index=False, encoding="utf-8-sig")
        ingest_labelled(path, csv, csv.name, platform, config.DEMO_LABEL_METHOD, is_demo=True)


def prepared():
    """Return (tmp_dir, db_path, models_dir, metrics)."""
    if "dir" not in _state:
        tmp = Path(tempfile.mkdtemp(prefix="reviewguard_tests_"))
        dbp = tmp / "test.db"
        make_demo_db(dbp)
        models = tmp / "models"
        with mock.patch.object(train_model, "candidate_models", fast_candidates):
            metrics = train_model.train(dbp, models, tmp / "img", make_plots=False, verbose=False)
        _state.update(dir=tmp, db=dbp, models=models, metrics=metrics)
    return _state["dir"], _state["db"], _state["models"], _state["metrics"]


def held_out_samples(lang, kind, n=150, seed=999, platform="Flipkart"):
    """New synthetic reviews from other random seeds. lang: en|hi|hg; kind: 'genuine_negative' | 'genuine_positive' | 'fake_promo'."""
    rng = random.Random(seed)
    out = []
    for _ in range(4000):
        if kind.startswith("genuine"):
            text, _title, rating = gen.genuine(lang, platform, rng)
            ok = rating <= 2 if kind == "genuine_negative" else rating >= 4
        else:
            text, _title, rating = gen.fake(lang, platform, rng)
            ok = "!" in text
        if lang == "hg":
            text = gen.hinglish_spelling(text, rng)
        if ok:
            out.append(text)
        if len(out) >= n:
            break
    return out


def cleanup():
    if "dir" in _state:
        shutil.rmtree(_state["dir"], ignore_errors=True)
        _state.clear()
