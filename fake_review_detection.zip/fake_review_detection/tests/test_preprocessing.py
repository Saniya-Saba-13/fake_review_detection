import unittest

import pandas as pd

from data_utils import encode_labels, prepare_dataset
from preprocessing import clean_text, text_signals


class CleanTextTests(unittest.TestCase):
    def test_lowercases_and_strips_html_and_urls(self):
        out = clean_text("<b>GREAT</b> product, see https://spam.example/x now")
        self.assertNotIn("<", out)
        self.assertNotIn("https", out)
        self.assertIn("great", out)
        self.assertIn("urltoken", out)

    def test_repeated_letters_squeezed(self):
        self.assertEqual(clean_text("sooooo good"), "soo good")

    def test_none_and_nan(self):
        self.assertEqual(clean_text(None), "")
        self.assertEqual(clean_text(float("nan")), "")

    def test_exclamation_kept_as_token(self):
        self.assertIn("!", clean_text("great!").split())


class SignalTests(unittest.TestCase):
    def test_promotional_and_short(self):
        names = [s["name"] for s in text_signals("Best product ever!!! Highly recommend, must buy now!!!")]
        self.assertIn("Promotional wording", names)
        self.assertIn("Many exclamation marks", names)

    def test_plain_long_review_has_no_signals(self):
        txt = "The jug is sturdy and crushes ice well but the lid is a bit hard to remove after washing it."
        self.assertEqual(text_signals(txt), [])


class DatasetTests(unittest.TestCase):
    def test_label_encoding(self):
        enc, unknown = encode_labels(pd.Series(["Genuine", "FAKE", "OR", "CG", "0", "1", "maybe"]))
        self.assertEqual(list(enc.dropna().astype(int)), [0, 1, 0, 1, 0, 1])
        self.assertEqual(unknown, ["maybe"])

    def test_prepare_removes_missing_duplicates_and_conflicts(self):
        raw = pd.DataFrame({
            "text_": ["good item works", "Good item works!", None, "   ", "same text", "same text", "unique fake text"],
            "label": ["OR", "OR", "OR", "OR", "OR", "CG", "CG"],
        })
        df, report = prepare_dataset(raw)
        self.assertEqual(report["missing_removed"], 2)
        self.assertEqual(report["conflicting_duplicates_removed"], 2)
        self.assertEqual(len(df), report["rows_final"])
        self.assertEqual(df["clean_text"].duplicated().sum(), 0)
        self.assertTrue(set(df["label"]).issubset({0, 1}))

    def test_missing_columns_raise(self):
        with self.assertRaises(ValueError):
            prepare_dataset(pd.DataFrame({"foo": ["a"], "bar": ["b"]}))

    def test_unknown_label_raises(self):
        with self.assertRaises(ValueError):
            prepare_dataset(pd.DataFrame({"text": ["abc def"], "label": ["maybe"]}))


if __name__ == "__main__":
    unittest.main()


class PastedReviewTests(unittest.TestCase):
    def test_amazon_paste_is_cleaned_and_detected(self):
        from preprocessing import clean_pasted_review
        raw = "5.0 out of 5 stars\nGreat phone\nReviewed in India \U0001F1EE\U0001F1F3 on 12 March 2024\nVerified Purchase\nBattery lasts two days and the camera is sharp.\n12 people found this helpful\nReport"
        out, info = clean_pasted_review(raw)
        self.assertIn("Battery lasts two days", out)
        for junk in ("Verified Purchase", "Reviewed in", "found this helpful", "Report"):
            self.assertNotIn(junk, out)
        self.assertEqual((info["platform"], info["rating"]), ("Amazon", 5.0))

    def test_flipkart_paste(self):
        from preprocessing import clean_pasted_review
        out, info = clean_pasted_review("Yeh product bahut accha hai, paisa vasool.\nCertified Buyer, Mumbai\n3 months ago\nHelpful for 12\nREAD MORE")
        self.assertIn("paisa vasool", out)
        self.assertNotIn("Certified", out)
        self.assertEqual(info["platform"], "Flipkart")

    def test_plain_review_is_untouched_and_never_emptied(self):
        from preprocessing import clean_pasted_review
        self.assertEqual(clean_pasted_review("Good product, fits well.")[0], "Good product, fits well.")
        self.assertEqual(clean_pasted_review("Verified Purchase")[0], "Verified Purchase")
