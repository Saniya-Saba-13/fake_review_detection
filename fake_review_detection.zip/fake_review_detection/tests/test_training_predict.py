import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np

import config
import db
import model_store
import train_model
from build_dataset import build_training_frame
from ingest import IngestError
from predict import FakeReviewPredictor, ModelNotFoundError, explanation_weights
from tests import helpers

SPEC = ["This product is amazing. The quality is excellent.", "Very bad product. Completely disappointed.", "यह प्रोडक्ट बहुत अच्छा है।",
        "इसकी क्वालिटी बहुत खराब है।", "मुझे यह प्रोडक्ट पसंद आया।", "Yeh product bahut accha hai.", "Iski quality bilkul bekar hai.",
        "Mujhe yeh product bahut pasand aaya."]


def tearDownModule():
    helpers.cleanup()


class TrainingTests(unittest.TestCase):
    def test_all_four_algorithm_families_are_candidates(self):
        names = {n for n, _f, _g in train_model.candidate_models()}
        self.assertEqual(names, {"Logistic Regression", "Multinomial Naive Bayes", "Linear SVM (calibrated)", "Random Forest"})

    def test_artifacts_registry_and_database(self):
        _tmp, dbp, models, meta = helpers.prepared()
        v = meta["version"]
        self.assertEqual(model_store.get_active(models), v)
        self.assertTrue((model_store.version_dir(models, v) / "model.joblib").exists())
        self.assertTrue((model_store.version_dir(models, v) / "metrics.json").exists())
        self.assertEqual([m["version"] for m in db.list_models(dbp) if m["is_active"]], [v])

    def test_metrics_are_reported_per_language_and_platform(self):
        _t, _d, _m, meta = helpers.prepared()
        t = meta["test_metrics"]
        self.assertEqual(set(t["by_language"]), {"English", "Hindi", "Hinglish"})
        self.assertEqual(set(t["by_platform"]), {"Meesho", "Flipkart", "Myntra", "Amazon"})
        for key in ("accuracy", "precision", "recall", "f1", "roc_auc", "confusion_matrix"):
            self.assertIn(key, t["overall"])
        for lang, m in t["by_language"].items():
            for key in ("n", "f1", "precision", "recall", "fpr", "predicted_fake_rate", "reliable"):
                self.assertIn(key, m, lang)
        self.assertIn("Negative", t["sentiment_check"])
        self.assertEqual(len(meta["validation_results"]), 2)   # the two fast candidates used in the fixture

    def test_demo_data_is_flagged_everywhere(self):
        _t, dbp, models, meta = helpers.prepared()
        self.assertTrue(meta["is_demo_data"])
        self.assertIn("DEMONSTRATION DATA", meta["notes"][0])
        self.assertTrue(model_store.list_versions(models)[0]["is_demo"])

    def test_no_review_text_is_shared_between_splits(self):
        _t, dbp, _m, _meta = helpers.prepared()
        df, _ = build_training_frame(dbp, include_demo=True)
        tr, va, te = train_model.split_frame(df)
        sets = [set(p["clean_text"]) for p in (tr, va, te)]
        self.assertFalse(sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])
        self.assertEqual(len(tr) + len(va) + len(te), len(df))
        for part in (tr, va, te):
            self.assertEqual(set(part["language"]), {"English", "Hindi", "Hinglish"})

    def test_balanced_per_language(self):
        _t, dbp, _m, meta = helpers.prepared()
        df, _ = build_training_frame(dbp, include_demo=True)
        for lang, g in df.groupby("language"):
            self.assertEqual(int((g["label"] == 0).sum()), int((g["label"] == 1).sum()), lang)

    def test_not_enough_data_is_refused(self):
        with tempfile.TemporaryDirectory() as d:
            dbp = Path(d) / "small.db"
            helpers.make_demo_db(dbp, n_genuine=3, n_fake=2)
            with self.assertRaises(IngestError) as cm:
                train_model.train(dbp, Path(d) / "m", Path(d) / "i", make_plots=False, verbose=False)
            self.assertIn("Not enough labelled data", str(cm.exception))

    def test_verified_data_is_preferred_when_enough_exists(self):
        with tempfile.TemporaryDirectory() as d:
            dbp = Path(d) / "x.db"
            helpers.make_demo_db(dbp, 5, 3)
            self.assertEqual(train_model.choose_rows(dbp, "auto")[0], True)       # only demo rows -> use them (flagged)
            rows = [{"platform": "Other", "review_text": f"verified review number {i} alpha", "rating": None, "label": i % 2, "label_method": "manual_annotation",
                     "collection_date": "2025-01-01", "language": "English", "text_hash": f"h{i}", "is_demo": 0} for i in range(config.MIN_ROWS_FOR_TRAINING)]
            db.insert_labelled(dbp, rows)
            self.assertEqual(train_model.choose_rows(dbp, "auto")[0], False)      # enough verified rows -> verified only
            self.assertEqual(train_model.choose_rows(dbp, "all")[0], True)

    def test_random_forest_explanation_weights_have_direction(self):
        _t, dbp, _m, _meta = helpers.prepared()
        df, _ = build_training_frame(dbp, include_demo=True)
        from sklearn.ensemble import RandomForestClassifier
        pipe = train_model.make_pipeline(RandomForestClassifier(n_estimators=30, random_state=0, n_jobs=1))
        pipe.fit(df["clean_text"], df["label"])
        feats = pipe.named_steps["features"]
        w = explanation_weights(pipe, feats.transform(df["clean_text"]).tocsr(), df["label"].to_numpy())
        self.assertEqual(len(w), len(feats.get_feature_names_out()))
        self.assertTrue((w > 0).any() and (w < 0).any())

    def test_transformer_script_explains_missing_dependencies(self):
        import train_transformer
        with mock.patch.dict(sys.modules, {"torch": None}):
            with self.assertRaises(SystemExit) as cm:
                train_transformer.require_torch()
        self.assertIn("pip install torch transformers", str(cm.exception))
        self.assertEqual(set(config.TRANSFORMER_CHOICES.values()), {"xlm-roberta-base", "bert-base-multilingual-cased", "ai4bharat/indic-bert"})


class PredictorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _t, cls.dbp, cls.models, cls.meta = helpers.prepared()
        cls.p = FakeReviewPredictor(cls.models)

    def test_result_structure_for_spec_sentences(self):
        for r in self.p.predict_many(SPEC):
            self.assertIn(r["label"], {"Likely Fake", "Likely Genuine"})
            self.assertAlmostEqual(r["fake_probability"] + r["genuine_probability"], 1.0, places=3)
            self.assertIn(r["language"]["language"], {"English", "Hindi", "Hinglish"})
            self.assertIn(r["sentiment"]["label"], {"Positive", "Negative"})
            self.assertEqual(r["model_version"], self.meta["version"])
            self.assertIn("not evidence of a fake review", r["explanation"])
            self.assertIn("not proof", r["disclaimer"])

    def test_language_and_sentiment_of_spec_sentences(self):
        langs = [r["language"]["language"] for r in self.p.predict_many(SPEC)]
        self.assertEqual(langs, ["English"] * 2 + ["Hindi"] * 3 + ["Hinglish"] * 3)
        sent = [r["sentiment"]["label"] for r in self.p.predict_many(SPEC)]
        self.assertEqual(sent, ["Positive", "Negative", "Positive", "Negative", "Positive", "Positive", "Negative", "Positive"])

    def test_platform_title_and_rating_are_passed_through(self):
        r = self.p.predict_many([{"text": "Yeh kurta accha hai", "title": "Mast", "platform": "Myntra", "rating": 5}])[0]
        self.assertEqual((r["platform"], r["rating"]), ("Myntra", 5))

    def test_all_platform_labels_work(self):
        for platform in config.PLATFORMS:
            self.assertEqual(self.p.predict_many([{"text": "Good quality and fast delivery", "platform": platform}])[0]["platform"], platform)

    def test_promotional_reviews_are_flagged_in_every_language(self):
        for lang in ("en", "hi", "hg"):
            texts = helpers.held_out_samples(lang, "fake_promo", n=60)
            rate = np.mean([r["label"] == "Likely Fake" for r in self.p.predict_many(texts)])
            self.assertGreater(rate, 0.75, f"{lang}: only {rate:.0%} of promotional reviews flagged")

    def test_genuine_negative_and_positive_reviews_are_not_flagged_fake(self):
        for lang in ("en", "hi", "hg"):
            for kind in ("genuine_negative", "genuine_positive"):
                texts = helpers.held_out_samples(lang, kind, n=60)
                rate = np.mean([r["label"] == "Likely Fake" for r in self.p.predict_many(texts)])
                self.assertLess(rate, 0.35, f"{lang}/{kind}: {rate:.0%} of genuine reviews flagged as fake")

    def test_hindi_and_hinglish_genuine_reviews_are_not_flagged_more_than_english(self):
        rates = {}
        for lang in ("en", "hi", "hg"):
            texts = helpers.held_out_samples(lang, "genuine_positive", n=80, seed=31) + helpers.held_out_samples(lang, "genuine_negative", n=80, seed=32)
            rates[lang] = np.mean([r["label"] == "Likely Fake" for r in self.p.predict_many(texts)])
        self.assertLess(rates["hi"] - rates["en"], 0.2, rates)
        self.assertLess(rates["hg"] - rates["en"], 0.2, rates)

    def test_repetitive_review_shows_the_repetition_signal(self):
        r = self.p.predict_one("Great great great great great great great great great great")
        self.assertIn("Repeated wording", [s["name"] for s in r["signals"]])

    def test_unknown_words_are_low_confidence(self):
        self.assertTrue(self.p.predict_one("zzqx qqwv xkcd")["low_confidence"])

    def test_explanations_show_terms_in_hindi_and_hinglish(self):
        for text in ("सबसे बढ़िया प्रोडक्ट!!! पैसा वसूल, जरूर खरीदें, पांच स्टार!!!", "Sabse accha product accha price accha seller. Five star! Abhi order karein!!!"):
            r = self.p.predict_one(text)
            self.assertTrue(r["top_fake_terms"] or r["top_genuine_terms"], text)

    def test_batch_equals_single(self):
        a = self.p.predict_many(SPEC[:3])
        for text, r in zip(SPEC[:3], a):
            self.assertEqual(self.p.predict_one(text)["label"], r["label"])

    def test_missing_corrupt_and_reload(self):
        with self.assertRaises(ModelNotFoundError) as cm:
            FakeReviewPredictor("/no/such/models").ensure_loaded()
        self.assertIn("train_model.py", str(cm.exception))
        with tempfile.TemporaryDirectory() as d:
            m = Path(d) / "models"
            v1 = model_store.version_dir(m, "v1")
            shutil.copytree(model_store.version_dir(self.models, self.meta["version"]), v1)
            model_store.set_active(m, "v1")
            p = FakeReviewPredictor(m)
            self.assertEqual(p.ensure_loaded().version, "v1")
            v2 = model_store.version_dir(m, "v2")
            shutil.copytree(v1, v2)
            model_store.set_active(m, "v2")
            self.assertEqual(p.ensure_loaded().version, "v2")          # picks up the newly activated version
            (v2 / "model.joblib").write_bytes(b"corrupt")
            with self.assertRaises(ModelNotFoundError):
                FakeReviewPredictor(m).ensure_loaded()


if __name__ == "__main__":
    unittest.main()
