import io
import re
import shutil
import time
import unittest
from pathlib import Path
from unittest import mock

import pandas as pd

import config
import train_model
from app import create_app
from tests import helpers


def tearDownModule():
    helpers.cleanup()


_counter = [0]


def make_app(**extra):
    """App with its own copy of the prepared test database, so tests cannot affect each other."""
    tmp, dbp, models, _meta = helpers.prepared()
    _counter[0] += 1
    own = tmp / f"app_{_counter[0]}.db"
    shutil.copy(dbp, own)
    cfg = {"TESTING": True, "DB_PATH": own, "MODELS_DIR": models, "IMAGES_DIR": tmp / "img"}
    cfg.update(extra)
    return create_app(cfg)


def upload(c, url, data, name, **form):
    return c.post(url, data={"file": (io.BytesIO(data), name), **form}, content_type="multipart/form-data")


class PagesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = make_app().test_client()

    def test_all_pages_render(self):
        for path in ["/", "/single", "/bulk", "/history", "/about"]:
            r = self.c.get(path)
            self.assertEqual(r.status_code, 200, path)
            self.assertIn(b"ReviewGuard", r.data)

    def test_navigation_contains_required_sections(self):
        html = self.c.get("/").get_data(as_text=True)
        for text in ("Home", "Check one review", "Check many reviews", "Past checks", "About"):
            self.assertIn(text, html)

    def test_static_files_and_template_references_exist(self):
        root = Path(config.BASE_DIR)
        for tpl in (root / "templates").glob("*.html"):
            for ref in re.findall(r"filename='([^']+)'", tpl.read_text(encoding="utf-8")):
                self.assertTrue((root / "static" / ref).exists(), f"{tpl.name} -> missing static/{ref}")
        for f in ("main.js", "dashboard.js", "analyze.js", "bulk.js", "results.js"):
            r = self.c.get(f"/static/js/{f}")
            self.assertEqual(r.status_code, 200)
            r.close()

    def test_every_element_id_used_by_javascript_exists_in_its_page(self):
        root = Path(config.BASE_DIR)
        pairs = {"dashboard.js": "index.html", "analyze.js": "single_review.html", "bulk.js": "bulk_review.html", "results.js": "history.html"}
        base = (root / "templates" / "base.html").read_text(encoding="utf-8")
        for js, tpl in pairs.items():
            src = (root / "static" / "js" / js).read_text(encoding="utf-8")
            ids = set(re.findall(r'\$\("([A-Za-z0-9_]+)"\)', src))
            html = (root / "templates" / tpl).read_text(encoding="utf-8") + base
            have = set(re.findall(r'id="([A-Za-z0-9_]+)"', html))
            dynamic = {"bl", "bs"}  # created by bulk.js itself
            self.assertEqual(sorted(ids - have - dynamic), [], js)

    def test_unknown_routes(self):
        self.assertEqual(self.c.get("/nope").status_code, 404)
        r = self.c.get("/api/nope")
        self.assertEqual((r.status_code, r.get_json()["ok"]), (404, False))

    def test_sample_downloads(self):
        for url in ("/download/sample-csv", "/download/sample-xlsx"):
            r = self.c.get(url)
            self.assertEqual(r.status_code, 200)
            r.close()


class PredictApiTests(unittest.TestCase):
    def setUp(self):
        self.c = make_app().test_client()
        self.c.delete("/api/history")

    def post(self, body):
        return self.c.post("/api/predict", json=body)

    def test_english_hindi_hinglish_with_each_platform(self):
        cases = [("This product is amazing. The quality is excellent.", "English", "Amazon"), ("यह प्रोडक्ट बहुत अच्छा है।", "Hindi", "Meesho"),
                 ("Yeh product bahut accha hai.", "Hinglish", "Flipkart"), ("इसकी क्वालिटी बहुत खराब है।", "Hindi", "Myntra"),
                 ("Very bad product. Completely disappointed.", "English", "Other")]
        for text, lang, platform in cases:
            r = self.post({"review": text, "platform": platform})
            self.assertEqual(r.status_code, 200, text)
            res = r.get_json()["result"]
            self.assertEqual((res["language"]["language"], res["platform"]), (lang, platform))
            for key in ("label", "display_label", "confidence", "sentiment", "language", "top_fake_terms", "top_genuine_terms", "explanation", "disclaimer", "model_version", "id"):
                self.assertIn(key, res)

    def test_negative_sentiment_is_reported_but_not_a_verdict(self):
        res = self.post({"review": "Iski quality bilkul bekar hai.", "platform": "Myntra"}).get_json()["result"]
        self.assertEqual(res["sentiment"]["label"], "Negative")
        self.assertIn("not evidence of a fake review", res["explanation"])

    def test_invalid_inputs(self):
        for body, status in [({}, 400), ({"review": ""}, 400), ({"review": "   "}, 400), ({"review": 5}, 400), ({"review": "12345 !!!"}, 400),
                             ({"review": "good", "platform": "eBay"}, 400), ({"review": "good one", "rating": 9}, 400),
                             ({"review": "good one", "rating": "abc"}, 400), ({"review": "a" * (config.MAX_REVIEW_CHARS + 1)}, 413)]:
            r = self.post(body)
            self.assertEqual(r.status_code, status, str(body)[:50])
            self.assertFalse(r.get_json()["ok"])
        self.assertEqual(self.c.post("/api/predict", data="x", content_type="text/plain").status_code, 400)

    def test_prediction_is_stored_in_the_database(self):
        self.post({"review": "Yeh product bahut accha hai.", "platform": "Flipkart", "rating": 5, "title": "Mast"})
        items = self.c.get("/api/history").get_json()["items"]
        self.assertEqual(len(items), 1)
        row = items[0]
        self.assertEqual((row["platform"], row["language"], row["source_type"], row["rating"]), ("Flipkart", "Hinglish", "manual", 5.0))
        self.assertTrue(row["created_at"] and row["model_version"] and row["prediction"] and row["sentiment"])


    def test_product_is_optional_validated_and_stored(self):
        r = self.post({"review": "Yeh kurta bahut accha hai.", "platform": "Myntra", "product": "  Kurti / Kurta Set "})
        self.assertEqual(r.get_json()["result"]["product"], "Kurti / Kurta Set")
        self.assertEqual(self.c.get("/api/history").get_json()["items"][0]["product"], "Kurti / Kurta Set")
        self.assertIsNone(self.post({"review": "Good phone, works well."}).get_json()["result"]["product"])
        bad = self.post({"review": "Good phone, works well.", "product": "x" * (config.MAX_PRODUCT_CHARS + 1)})
        self.assertEqual(bad.status_code, 400)


    def test_product_mismatch_raises_suspicion_and_match_does_not(self):
        text = "Great air fryer, cooks evenly and the basket is easy to wash."
        plain = self.post({"review": text}).get_json()["result"]
        wrong = self.post({"review": text, "product": "Saree"}).get_json()["result"]
        right = self.post({"review": text, "product": "Air Fryer"}).get_json()["result"]
        self.assertEqual(wrong["product_check"]["level"], "mismatch")
        self.assertTrue(wrong["product_check"]["raised_suspicion"])
        self.assertGreater(wrong["fake_probability"], plain["fake_probability"])
        self.assertEqual(right["product_check"]["level"], "match")
        self.assertAlmostEqual(right["fake_probability"], plain["fake_probability"], places=3)

    def test_generic_review_is_not_penalised_for_any_product(self):
        a = self.post({"review": "Good quality, fast delivery, value for money."}).get_json()["result"]
        b = self.post({"review": "Good quality, fast delivery, value for money.", "product": "Smartphone"}).get_json()["result"]
        self.assertEqual(b["product_check"]["level"], "unknown")
        self.assertEqual(a["fake_probability"], b["fake_probability"])


    def test_repeated_hinglish_phrase_is_flagged_and_explained(self):
        r = self.post({"review": "Bahut accha product hai bahut accha product hai bahut accha product hai best best best"}).get_json()["result"]
        self.assertTrue(r["language_check"]["applied"])
        self.assertTrue(r["language_check"]["raised_suspicion"])
        self.assertTrue(any("repeated" in s["detail"].lower() for s in r["signals"]))

    def test_english_review_is_not_touched_by_hinglish_checks(self):
        r = self.post({"review": "Excellent product, worth the money."}).get_json()["result"]
        self.assertFalse(r["language_check"]["applied"])
        self.assertFalse(r["language_check"]["raised_suspicion"])


class BulkApiTests(unittest.TestCase):
    def setUp(self):
        self.c = make_app().test_client()
        self.c.delete("/api/history")

    def test_json_batch_with_invalid_entries(self):
        r = self.c.post("/api/predict-bulk", json={"reviews": ["Good quality", "", "यह प्रोडक्ट अच्छा है", 5, "Best ever!!! must buy"], "platform": "Meesho"})
        self.assertEqual(r.status_code, 200)
        d = r.get_json()
        self.assertEqual((d["summary"]["total"], d["summary"]["skipped"]), (3, 2))
        self.assertEqual(set(d["summary"]["by_platform"]), {"Meesho"})
        self.assertEqual(set(d["summary"]["by_language"]), {"English", "Hindi"})

    def test_csv_upload_with_hindi_and_per_row_platforms(self):
        data = Path(config.SAMPLE_UPLOAD_MULTI_CSV).read_bytes()
        d = upload(self.c, "/api/predict-bulk", data, "reviews.csv", platform="Other").get_json()
        self.assertEqual(d["summary"]["total"], 16)
        self.assertEqual(set(d["summary"]["by_platform"]), {"Amazon", "Flipkart", "Meesho", "Myntra", "Other"})
        self.assertEqual(set(d["summary"]["by_language"]) & {"English", "Hindi", "Hinglish"}, {"English", "Hindi", "Hinglish"})

    def test_excel_upload(self):
        data = Path(config.SAMPLE_UPLOAD_MULTI_XLSX).read_bytes()
        r = upload(self.c, "/api/predict-bulk", data, "reviews.xlsx")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["summary"]["total"], 16)
        batch = self.c.get("/api/history").get_json()["items"][0]
        self.assertEqual(batch["source_type"], "batch_xlsx")

    def test_invalid_uploads(self):
        for data, name, status in [(b"review\nabc def", "x.txt", 415), (b"review\nabc def", "x.xls", 415), (b"foo,bar\n1,2\n", "x.csv", 400), (b"", "x.csv", 400),
                                   (b"review\n\n\n", "x.csv", 400), (b"not a zip", "x.xlsx", 400), (b"review,rating\ngood one,9\n", "x.csv", 400)]:
            r = upload(self.c, "/api/predict-bulk", data, name)
            self.assertEqual(r.status_code, status, f"{name} {data[:12]}")
            self.assertFalse(r.get_json()["ok"])

    def test_limits(self):
        self.assertEqual(self.c.post("/api/predict-bulk", json={"reviews": ["ok review"] * (config.MAX_BULK_REVIEWS + 1)}).status_code, 400)
        self.assertEqual(self.c.post("/api/predict-bulk", json={"reviews": []}).status_code, 400)
        self.assertEqual(self.c.post("/api/predict-bulk", json={"nothing": 1}).status_code, 400)
        big = b"review\n" + b"a good review here\n" * 400000
        self.assertEqual(upload(self.c, "/api/predict-bulk", big, "big.csv").status_code, 413)

    def test_history_filters_and_clear(self):
        self.c.post("/api/predict-bulk", json={"reviews": ["Yeh product bahut accha hai", "This is a very good product indeed"], "platform": "Amazon"})
        self.c.post("/api/predict", json={"review": "इसकी क्वालिटी बहुत खराब है।", "platform": "Meesho"})
        h = self.c.get("/api/history?platform=Amazon").get_json()
        self.assertEqual(len(h["items"]), 2)
        self.assertEqual(len(self.c.get("/api/history?language=Hindi").get_json()["items"]), 1)
        self.assertEqual(self.c.get("/api/history?limit=abc").status_code, 400)
        stats = self.c.get("/api/stats").get_json()["analyses"]
        self.assertEqual(stats["total"], 3)
        self.assertEqual(self.c.delete("/api/history").get_json()["removed"], 3)
        self.assertEqual(self.c.get("/api/stats").get_json()["analyses"]["total"], 0)


class DataAndModelApiTests(unittest.TestCase):
    def setUp(self):
        self.c = make_app().test_client()

    def test_platform_status_is_honest(self):
        d = self.c.get("/api/platforms").get_json()
        self.assertEqual([p["name"] for p in d["platforms"]], config.PLATFORMS)
        self.assertFalse(d["live_integration_available"])
        self.assertTrue(all(p["live_api"] is False for p in d["platforms"]))
        amazon = next(p for p in d["platforms"] if p["name"] == "Amazon")
        self.assertIn("does not return customer reviews", amazon["note"])

    def test_dataset_info_and_model_info(self):
        d = self.c.get("/api/dataset-info").get_json()
        self.assertGreater(d["labelled"]["total"], 0)
        self.assertEqual({r["name"] for r in d["labelled"]["by_platform"]}, {"Meesho", "Flipkart", "Myntra", "Amazon"})
        self.assertEqual({r["name"] for r in d["labelled"]["by_language"]}, {"English", "Hindi", "Hinglish"})
        info = self.c.get("/api/model-info").get_json()
        self.assertIn("test_metrics", info["metrics"])
        self.assertEqual(self.c.get("/api/models").get_json()["versions"][0]["version"], info["version"])
        h = self.c.get("/api/health").get_json()
        self.assertTrue(h["model_loaded"] and h["model_is_demo"])

    def test_ingest_endpoint(self):
        df = pd.DataFrame({"review": ["alpha verified review one", "beta verified review two"], "label": ["genuine", "fake"]})
        data = df.to_csv(index=False).encode("utf-8")
        r = upload(self.c, "/api/ingest", data, "labels.csv", platform="Myntra", label_method="manual_annotation")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["report"]["rows_added"], 2)
        again = upload(self.c, "/api/ingest", data, "labels.csv", platform="Myntra", label_method="manual_annotation").get_json()["report"]
        self.assertEqual((again["rows_added"], again["duplicates"]), (0, 2))
        no_method = upload(self.c, "/api/ingest", data.replace(b"alpha", b"gamma"), "labels.csv", platform="Myntra")
        self.assertEqual(no_method.status_code, 400)
        self.assertIn("label_method", no_method.get_json()["error"])
        self.assertEqual(self.c.post("/api/ingest", data={}).status_code, 400)
        self.assertEqual(upload(self.c, "/api/ingest", data, "labels.csv", platform="NotAShop", label_method="m").status_code, 400)

    def test_local_only_actions_are_refused_for_remote_clients(self):
        remote = {"REMOTE_ADDR": "10.1.2.3"}
        self.assertEqual(self.c.post("/api/retrain", json={}, environ_base=remote).status_code, 403)
        self.assertEqual(self.c.post("/api/ingest", data={}, environ_base=remote).status_code, 403)
        self.assertEqual(self.c.post("/api/models/activate", json={"version": "x"}, environ_base=remote).status_code, 403)

    def test_retrain_job_end_to_end_and_activation(self):
        tmp, dbp, _models, _meta = helpers.prepared()
        models = tmp / "retrain_models"
        c = make_app(MODELS_DIR=models).test_client()
        self.assertEqual(c.post("/api/retrain", json={"data_mode": "bogus"}).status_code, 400)
        with mock.patch.object(train_model, "candidate_models", helpers.fast_candidates):
            r = c.post("/api/retrain", json={"data_mode": "all", "balance": True})
            self.assertEqual(r.status_code, 202)
            for _ in range(240):
                st = c.get("/api/retrain/status").get_json()["training"]
                if st["status"] != "running":
                    break
                time.sleep(0.5)
        self.assertEqual(st["status"], "done", st)
        self.assertTrue(st["is_demo"])
        self.assertEqual(c.get("/api/health").get_json()["model_version"], st["version"])
        self.assertEqual(c.post("/api/models/activate", json={"version": "nope"}).status_code, 404)
        self.assertEqual(c.post("/api/models/activate", json={"version": st["version"]}).status_code, 200)

    def test_without_a_model_the_site_works_and_the_api_explains(self):
        tmp, dbp, _m, _meta = helpers.prepared()
        c = create_app({"TESTING": True, "DB_PATH": tmp / "nomodel.db", "MODELS_DIR": tmp / "does_not_exist"}).test_client()
        home = c.get("/")
        self.assertEqual(home.status_code, 200)
        self.assertIn(b"No trained model yet", home.data)
        for path in ("/single", "/bulk", "/history"):
            self.assertEqual(c.get(path).status_code, 200, path)
        r = c.post("/api/predict", json={"review": "good product"})
        self.assertEqual(r.status_code, 503)
        self.assertIn("train_model.py", r.get_json()["error"])
        self.assertEqual(c.post("/api/predict-bulk", json={"reviews": ["good product"]}).status_code, 503)
        self.assertFalse(c.get("/api/health").get_json()["model_loaded"])


if __name__ == "__main__":
    unittest.main()
