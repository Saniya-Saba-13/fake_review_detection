import unittest

import hinglish_support as hs
from multilingual import normalize_for_model as nm


class HinglishSupportTests(unittest.TestCase):
    def test_bridge_adds_english_meaning_and_keeps_original(self):
        extra, found = hs.english_bridge(nm("Paisa vasool, bahut accha product hai"), "Hinglish")
        self.assertIn("value for money", extra)
        self.assertIn("very good", extra)
        self.assertTrue(found)

    def test_bridge_does_nothing_for_english_or_unknown(self):
        self.assertEqual(hs.english_bridge("great product", "English"), ("", []))
        self.assertEqual(hs.english_bridge("", "Hinglish"), ("", []))

    def test_hindi_devanagari_is_bridged(self):
        extra, _ = hs.english_bridge(nm("यह प्रोडक्ट बहुत अच्छा है"), "Hindi")
        self.assertIn("very", extra)
        self.assertIn("good", extra)

    def test_repetition_is_detected_only_for_non_english(self):
        t = "Bahut accha product hai bahut accha product hai bahut accha product hai best best best"
        self.assertTrue(hs.spam_patterns(t, "Hinglish")["repeat"])
        self.assertFalse(hs.spam_patterns(t, "English")["repeat"])      # English behaviour is deliberately unchanged

    def test_normal_detailed_hinglish_review_is_not_flagged(self):
        t = "Maine yeh kurti do hafte pehle li thi, fitting achhi hai lekin colour photo se thoda halka hai. Silai bhi sahi hai."
        r = hs.spam_patterns(t, "Hinglish")
        self.assertEqual((r["repeat"], r["stack"], r["boost_logit"]), (False, False, 0.0))

    def test_stacked_hype_is_detected(self):
        t = "Best product ever!!! Paisa vasool, must buy, 5 star, zabardast, sabko lena chahiye!!!"
        self.assertTrue(hs.spam_patterns(t, "Hinglish")["stack"])

    def test_adjustment_only_raises_and_is_capped(self):
        p, hit = hs.adjust_probability(0.3, {"boost_logit": 2.0})
        self.assertTrue(hit)
        self.assertGreater(p, 0.3)
        self.assertLess(p, 0.9)
        self.assertEqual(hs.adjust_probability(0.3, {"boost_logit": 0.0}), (0.3, False))


if __name__ == "__main__":
    unittest.main()
