# -*- coding: utf-8 -*-
"""v23: Hinglish converter, language detection of mixed reviews, contact-spam pattern and the hand-written Hinglish evaluation."""
import random
import unittest

import pandas as pd
from sklearn.linear_model import LogisticRegression

import hinglish_augment as aug
import hinglish_support
import train_model
from multilingual import detect_language


class ConverterTests(unittest.TestCase):
    def test_converts_and_is_deterministic(self):
        text = "Great product. The quality is very good but delivery was late. Value for money, highly recommended."
        a, b = aug.to_hinglish(text, random.Random(5)), aug.to_hinglish(text, random.Random(5))
        self.assertEqual(a, b)
        self.assertNotEqual(a.lower(), text.lower())
        self.assertEqual(detect_language(a)["language"], "Hinglish")

    def test_keeps_the_meaning_words_that_are_not_translated(self):
        out = aug.to_hinglish("The mixer grinder jar broke after two weeks", random.Random(1)).lower()
        self.assertIn("mixer grinder", out)

    def test_augment_training_balanced_and_labelled(self):
        rows = [{"model_text": "Good quality product, very happy, value for money", "label": 0, "language": "English", "platform": "Flipkart"},
                {"model_text": "Bad product, waste of money, very disappointed with the quality", "label": 1, "language": "English", "platform": "Amazon"}] * 40
        out = aug.augment_training(pd.DataFrame(rows), per_class=25)
        self.assertEqual(set(out["language"]), {"Hinglish"})
        self.assertEqual((out["label"] == 0).sum(), (out["label"] == 1).sum())
        self.assertTrue((out["label_method"] == "augmented_hinglish").all())
        self.assertTrue(out["clean_text"].str.len().gt(0).all())

    def test_only_english_rows_are_used_as_source(self):
        rows = [{"model_text": "yeh bahut accha hai", "label": 0, "language": "Hinglish", "platform": "Other"}] * 10
        self.assertEqual(len(aug.augment_training(pd.DataFrame(rows), per_class=5)), 0)


class DetectionAndPatternTests(unittest.TestCase):
    def test_mixed_review_is_hinglish(self):
        self.assertEqual(detect_language("Best product ever!!! Must buy, paisa vasool, sabko recommend karunga, 5 star!!!")["language"], "Hinglish")

    def test_plain_english_stays_english(self):
        for t in ["The battery lasts all day and the screen is bright.", "Good quality for the price, delivered on time.", "I put the mat on the floor and it stays in place."]:
            self.assertEqual(detect_language(t)["language"], "English", t)

    def test_contact_pattern(self):
        spam = "Order karo aur free gift pao! Contact karo WhatsApp 9876501234 pe"
        res = hinglish_support.spam_patterns(spam, "Hinglish")
        self.assertTrue(res["contact"])
        self.assertGreater(res["boost_logit"], 0)
        ok = hinglish_support.spam_patterns("Delivery 3 din mein hui, product accha hai aur seller ne call kiya tha.", "Hinglish")
        self.assertFalse(ok["contact"])

    def test_contact_pattern_never_touches_english(self):
        res = hinglish_support.spam_patterns("Call me on WhatsApp 9876501234", "English")
        self.assertEqual((res["contact"], res["boost_logit"]), (False, 0.0))


class HinglishEvalTests(unittest.TestCase):
    def test_eval_file_has_both_classes_in_dev_and_test(self):
        ev = pd.read_csv(train_model.HINGLISH_EVAL_PATH, encoding="utf-8-sig")
        for split in ("dev", "test"):
            sub = ev[ev["split"] == split]
            self.assertEqual(sorted(sub["label"].value_counts().to_dict().items()), [("fake", 20), ("genuine", 20)])
        self.assertEqual(ev["review"].duplicated().sum(), 0)
        self.assertTrue((ev["label_method"] == "author_written_test").all())

    def test_hinglish_eval_reports_measured_numbers(self):
        ev = pd.read_csv(train_model.HINGLISH_EVAL_PATH, encoding="utf-8-sig")
        train = pd.DataFrame({"t": ["accha product mast quality", "bekar ghatiya waste", "zabardast must buy best best"] * 10, "y": [0, 0, 1] * 10})
        pipe = train_model.make_pipeline(LogisticRegression(max_iter=500))
        pipe.set_params(features__word__min_df=1, features__char__min_df=1)
        pipe.fit(train["t"], train["y"])
        out = train_model.hinglish_eval(pipe)
        self.assertEqual(set(out), {"dev", "test"})
        self.assertEqual(out["test"]["n"], 40)
        self.assertIn("hand-written", out["test"]["source"])
        self.assertIsInstance(out["test"]["reliable"], bool)
        self.assertEqual(len(ev), 80)

    def test_reliable_requires_decent_quality(self):
        """Enough test reviews alone is not enough: a model that cannot beat the thresholds must stay 'not very sure'."""
        pipe = train_model.make_pipeline(LogisticRegression(max_iter=500))
        pipe.set_params(features__word__min_df=1, features__char__min_df=1)
        pipe.fit(["aaa bbb", "ccc ddd"] * 5, [0, 1] * 5)       # knows nothing about the eval vocabulary; only the rule layer helps
        out = train_model.hinglish_eval(pipe)["test"]
        self.assertFalse(out["reliable"])
        self.assertIn("rules_only_baseline", out)


class ShippedModelTests(unittest.TestCase):
    def test_shipped_model_judges_hinglish_with_measured_numbers(self):
        import config
        import model_store
        import json
        v = model_store.get_active(config.MODELS_DIR)
        if not v:
            self.skipTest("no model installed")
        m = json.loads((model_store.version_dir(config.MODELS_DIR, v) / "metrics.json").read_text(encoding="utf-8"))
        if "hinglish_eval" not in m:
            self.skipTest("model trained before v23")
        self.assertIn("hand-written", m["test_metrics"]["by_language"]["Hinglish"]["source"])
        self.assertTrue(m["hinglish_augmentation"]["applied_to"].startswith("training split only"))


if __name__ == "__main__":
    unittest.main()
