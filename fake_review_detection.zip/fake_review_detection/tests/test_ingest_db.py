import io
import tempfile
import unittest
from pathlib import Path

import pandas as pd

import config
import db
from build_dataset import balance_by_language, build_training_frame
from ingest import IngestError, ingest_labelled, normalize_platform, prepare_labelled, prepare_unlabelled, read_table, text_hash


def csv_bytes(df, enc="utf-8-sig"):
    return df.to_csv(index=False).encode(enc)


def xlsx_bytes(df):
    buf = io.BytesIO()
    df.to_excel(buf, index=False, engine="openpyxl")
    return buf.getvalue()


LAB = pd.DataFrame({"review": ["यह प्रोडक्ट बहुत अच्छा है और काम करता है", "Best product ever!!! must buy now!!!", "Quality theek hai, delivery late thi"],
                    "label": ["genuine", "fake", "OR"], "platform": ["Meesho", "Amazon India", "flipkart.com"], "rating": ["5", "9", "x"]})


class ReadTableTests(unittest.TestCase):
    def test_csv_with_hindi_and_bom(self):
        df = read_table(csv_bytes(LAB), "a.csv")
        self.assertEqual(df["review"][0], LAB["review"][0])

    def test_xlsx_round_trip_with_hindi(self):
        df = read_table(xlsx_bytes(LAB), "a.xlsx")
        self.assertEqual(list(df["review"]), list(LAB["review"]))

    def test_cp1252_fallback(self):
        df = read_table("review,label\ncafé good,genuine\n".encode("cp1252"), "a.csv")
        self.assertEqual(df["review"][0], "café good")

    def test_rejections(self):
        for data, name, fragment in [(b"x", "a.xls", ".xlsx"), (b"x", "a.txt", "Only .csv"), (b"   ", "a.csv", "empty"),
                                     (b"a\x00b", "a.csv", "text CSV"), (b"not a zip", "a.xlsx", "valid .xlsx")]:
            with self.assertRaises(IngestError, msg=name) as cm:
                read_table(data, name)
            self.assertIn(fragment, str(cm.exception))

    def test_corrupt_xlsx_is_reported_cleanly(self):
        with self.assertRaises(IngestError):
            read_table(b"PK\x03\x04 broken", "a.xlsx")

    def test_row_limit(self):
        with self.assertRaises(IngestError):
            read_table(csv_bytes(pd.DataFrame({"review": ["a b"] * 6})), "a.csv", max_rows=5)


class PlatformTests(unittest.TestCase):
    def test_normalisation(self):
        self.assertEqual([normalize_platform(x) for x in ("Amazon India", "flipkart.com", "MEESHO", "myntra", "ebay", "", None)],
                         ["Amazon", "Flipkart", "Meesho", "Myntra", "Other", "Other", "Other"])

    def test_all_four_platforms_and_other_are_configured(self):
        self.assertEqual(config.PLATFORMS, ["Meesho", "Flipkart", "Myntra", "Amazon", "Other"])


class PrepareLabelledTests(unittest.TestCase):
    def test_label_method_is_required(self):
        with self.assertRaises(IngestError) as cm:
            prepare_labelled(LAB.copy())
        self.assertIn("label_method", str(cm.exception))

    def test_rows_columns_and_cleaning(self):
        rows, rep = prepare_labelled(LAB.copy(), "f.csv", "Other", "manual_annotation")
        self.assertEqual([r["platform"] for r in rows], ["Meesho", "Amazon", "Flipkart"])
        self.assertEqual([r["label"] for r in rows], [0, 1, 0])
        self.assertEqual([r["language"] for r in rows], ["Hindi", "English", "Hinglish"])
        self.assertEqual(rep["rating_cleared"], 2)               # 9 and 'x' are not valid 1-5 ratings
        self.assertEqual(rows[0]["rating"], 5.0)
        self.assertTrue(all(r["label_method"] == "manual_annotation" for r in rows))
        self.assertTrue(all(r["collection_date"] for r in rows))

    def test_invalid_rows_are_counted_with_reasons(self):
        df = pd.DataFrame({"review": ["", "good one here", "fine product", "x" * (config.MAX_REVIEW_CHARS + 1), "???"],
                           "label": ["fake", "maybe", "fake", "fake", "fake"]})
        rows, rep = prepare_labelled(df, "f.csv", "Other", "m")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rep["invalid"], 4)
        self.assertEqual(len(rep["invalid_reasons"]), 4)

    def test_per_row_label_method_column(self):
        df = pd.DataFrame({"review": ["alpha beta gamma"], "label": ["fake"], "label_method": ["moderator_removed"]})
        rows, _ = prepare_labelled(df)
        self.assertEqual(rows[0]["label_method"], "moderator_removed")

    def test_dates(self):
        df = pd.DataFrame({"review": ["one two three", "four five six"], "label": ["fake", "genuine"], "date": ["2025-03-04", "not a date"]})
        rows, rep = prepare_labelled(df, label_method="m")
        self.assertEqual(rows[0]["collection_date"], "2025-03-04")
        self.assertEqual(rep["date_defaulted"], 1)

    def test_missing_columns(self):
        with self.assertRaises(IngestError):
            prepare_labelled(pd.DataFrame({"foo": ["a"]}), label_method="m")

    def test_spelling_variants_hash_to_the_same_text(self):
        self.assertEqual(text_hash("Yeh product bahut accha hai"), text_hash("ye product bohot acha hai"))


class IngestToDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "t.db"

    def tearDown(self):
        self.tmp.cleanup()

    def test_ingest_dedupe_and_conflicts(self):
        df = pd.DataFrame({"review": ["alpha beta gamma delta", "ALPHA beta  gamma delta", "zeta eta theta iota"], "label": ["fake", "fake", "genuine"]})
        r1 = ingest_labelled(self.db, csv_bytes(df), "a.csv", "Myntra", "manual_annotation")
        self.assertEqual((r1["rows_added"], r1["duplicates"]), (2, 1))
        r2 = ingest_labelled(self.db, csv_bytes(df), "a.csv", "Myntra", "manual_annotation")
        self.assertEqual((r2["rows_added"], r2["duplicates"]), (0, 3))
        flipped = pd.DataFrame({"review": ["alpha beta gamma delta"], "label": ["genuine"]})
        r3 = ingest_labelled(self.db, csv_bytes(flipped), "b.csv", "Myntra", "manual_annotation")
        self.assertEqual((r3["rows_added"], r3["conflicts"]), (0, 1))
        s = db.labelled_summary(self.db)
        self.assertEqual((s["total"], s["verified"], s["demo"]), (2, 2, 0))
        self.assertEqual(len(s["ingestions"]), 3)

    def test_xlsx_ingest_stores_source_and_date(self):
        ingest_labelled(self.db, xlsx_bytes(LAB.drop(columns=["rating"])), "x.xlsx", "Other", "manual_annotation")
        rows = db.fetch_labelled(self.db)
        self.assertEqual({r["platform"] for r in rows}, {"Meesho", "Amazon", "Flipkart"})
        self.assertTrue(all(r["source_file"] == "x.xlsx" and r["collection_date"] for r in rows))

    def test_nothing_valid_raises(self):
        with self.assertRaises(IngestError):
            ingest_labelled(self.db, csv_bytes(pd.DataFrame({"review": [""], "label": ["fake"]})), "a.csv", "Other", "m")


class PrepareUnlabelledTests(unittest.TestCase):
    def test_items_and_skips(self):
        df = pd.DataFrame({"Review": ["good one", "", "!!!", "ok fine", "z" * 6000], "rating": ["5", "", "", "7", ""],
                           "platform": ["Meesho", "", "", "", ""]})
        items, skipped = prepare_unlabelled(df, "Amazon")
        self.assertEqual([i["platform"] for i in items], ["Meesho"])
        self.assertEqual(sorted(s["row"] for s in skipped), [2, 3, 4, 5])

    def test_requires_review_column_and_row_limit(self):
        with self.assertRaises(IngestError):
            prepare_unlabelled(pd.DataFrame({"foo": ["a"]}))
        with self.assertRaises(IngestError):
            prepare_unlabelled(pd.DataFrame({"review": ["ab"] * 4}), max_rows=3)


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "t.db"

    def tearDown(self):
        self.tmp.cleanup()

    def entry(self, label="Likely Fake", lang="Hindi", platform="Meesho"):
        return {"platform": platform, "language": lang, "review": "यह रिव्यू", "label": label, "fake_probability": 0.9, "confidence": 0.9,
                "low_confidence": False, "sentiment": {"label": "Positive", "score": 1.0}, "model_version": "v1", "top_fake_terms": [{"term": "x"}], "top_genuine_terms": []}

    def test_record_list_filter_stats_clear(self):
        bid = db.create_batch(self.db, "f.csv", "Meesho", 3)
        db.record_analyses(self.db, [self.entry(), self.entry("Likely Genuine", "English", "Amazon")], "batch_csv", bid)
        db.record_analyses(self.db, [self.entry("Likely Genuine", "Hinglish", "Myntra")], "manual")
        db.finish_batch(self.db, bid, 2, 1)
        self.assertEqual(len(db.list_analyses(self.db)), 3)
        self.assertEqual([r["platform"] for r in db.list_analyses(self.db, platform="Amazon")], ["Amazon"])
        self.assertEqual(len(db.list_analyses(self.db, label="Likely Fake")), 1)
        row = db.list_analyses(self.db, language="Hindi")[0]
        for key in ("created_at", "platform", "language", "model_version", "prediction", "sentiment"):
            self.assertTrue(row[key])
        s = db.analysis_stats(self.db)
        self.assertEqual((s["total"], s["fake"], s["genuine"], s["batches"]), (3, 1, 2, 1))
        self.assertEqual(db.clear_analyses(self.db), 3)
        self.assertEqual(db.analysis_stats(self.db)["total"], 0)

    def test_model_registry_activation(self):
        db.register_model(self.db, "v1", "sklearn: LR", "/x/v1", True, 0.9, 0.9, "s")
        db.register_model(self.db, "v2", "sklearn: SVM", "/x/v2", False, 0.8, 0.8, "s")
        self.assertEqual([m["version"] for m in db.list_models(self.db) if m["is_active"]], ["v2"])
        self.assertTrue(db.set_active_model(self.db, "v1"))
        self.assertEqual([m["version"] for m in db.list_models(self.db) if m["is_active"]], ["v1"])
        self.assertFalse(db.set_active_model(self.db, "nope"))


class BalancingTests(unittest.TestCase):
    def frame(self, spec):
        rows = []
        for lang, (n_gen, n_fake) in spec.items():
            rows += [{"language": lang, "label": 0}] * n_gen + [{"language": lang, "label": 1}] * n_fake
        return pd.DataFrame(rows)

    def test_languages_are_balanced_independently(self):
        out, rep = balance_by_language(self.frame({"English": (300, 100), "Hindi": (80, 60), "Hinglish": (200, 200)}))
        for lang, n in (("English", 100), ("Hindi", 60), ("Hinglish", 200)):
            sub = out[out["language"] == lang]
            self.assertEqual((int((sub["label"] == 0).sum()), int((sub["label"] == 1).sum())), (n, n))
        self.assertTrue(all(v["balanced"] for v in rep.values()))

    def test_tiny_groups_are_kept_not_balanced(self):
        out, rep = balance_by_language(self.frame({"English": (100, 100), "Hindi": (30, 5)}))
        self.assertFalse(rep["Hindi"]["balanced"])
        self.assertEqual(len(out[out["language"] == "Hindi"]), 35)

    def test_build_training_frame_empty_database_message(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(IngestError) as cm:
                build_training_frame(Path(d) / "e.db")
            self.assertIn("build_dataset.py --demo", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
