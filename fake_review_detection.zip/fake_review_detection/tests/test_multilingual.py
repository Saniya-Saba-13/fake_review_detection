import re
import unittest

from multilingual import TOKEN_PATTERN, detect_language, normalize_devanagari, normalize_for_model
from sentiment import analyze_sentiment

SPEC = {
    "English": ["This product is amazing. The quality is excellent.", "Very bad product. Completely disappointed."],
    "Hindi": ["यह प्रोडक्ट बहुत अच्छा है।", "इसकी क्वालिटी बहुत खराब है।", "मुझे यह प्रोडक्ट पसंद आया।"],
    "Hinglish": ["Yeh product bahut accha hai.", "Iski quality bilkul bekar hai.", "Mujhe yeh product bahut pasand aaya."],
}


class NormalisationTests(unittest.TestCase):
    def test_devanagari_variants_are_unified(self):
        self.assertEqual(normalize_devanagari("ज़बरदस्त"), normalize_devanagari("जबरदस्त"))       # nukta
        self.assertEqual(normalize_devanagari("हैं"), normalize_devanagari("हैँ"))                 # chandrabindu
        self.assertEqual(normalize_devanagari("अच्छा है।"), "अच्छा है.")                           # danda
        self.assertEqual(normalize_devanagari("१२३"), "123")                                       # Devanagari digits

    def test_hinglish_spelling_variants_share_one_form(self):
        for group in (["accha", "acha", "achha"], ["bahut", "bohot", "bahot"], ["nahi", "nahin", "nhi"], ["bekar", "bekaar"]):
            self.assertEqual(len({normalize_for_model(w) for w in group}), 1, group)

    def test_hindi_text_survives_cleaning(self):
        out = normalize_for_model("यह प्रोडक्ट बहुत अच्छा है।")
        self.assertIn("अच्छा", out.split())
        self.assertNotIn("।", out)

    def test_urls_html_emoji_repeats_and_none(self):
        out = normalize_for_model("<b>SOOOO good</b> 😀 see https://x.example/a !!!")
        self.assertNotIn("<", out); self.assertNotIn("https", out); self.assertIn("urltoken", out); self.assertIn("soo", out)
        self.assertEqual(normalize_for_model(None), "")
        self.assertEqual(normalize_for_model(float("nan")), "")

    def test_word_token_pattern_keeps_devanagari_words_whole(self):
        # regression: Python's \w splits Devanagari words at vowel signs; our pattern must not
        toks = re.findall(TOKEN_PATTERN, normalize_for_model("बहुत अच्छा है"))
        self.assertEqual(toks, ["बहुत", "अच्छा", "है"])


class LanguageDetectionTests(unittest.TestCase):
    def test_spec_examples(self):
        for lang, texts in SPEC.items():
            for t in texts:
                self.assertEqual(detect_language(t)["language"], lang, t)

    def test_mixed_script_and_unknown(self):
        self.assertEqual(detect_language("Product बहुत अच्छा hai but delivery late")["language"], "Mixed")
        for t in ("", "12345", "👍👍", None):
            self.assertEqual(detect_language(t)["language"], "Unknown")

    def test_english_with_ambiguous_words_is_not_hinglish(self):
        for t in ("I want to go to the shop and buy it in time", "The color is nice and it fits me well"):
            self.assertEqual(detect_language(t)["language"], "English", t)

    def test_confidence_level_present(self):
        self.assertIn(detect_language("ok")["confidence"], {"low", "medium", "high"})
        self.assertEqual(detect_language("यह प्रोडक्ट बहुत अच्छा है।")["confidence"], "high")


class SentimentTests(unittest.TestCase):
    def test_spec_examples(self):
        expected = {"This product is amazing. The quality is excellent.": "Positive", "Very bad product. Completely disappointed.": "Negative",
                    "यह प्रोडक्ट बहुत अच्छा है।": "Positive", "इसकी क्वालिटी बहुत खराब है।": "Negative", "मुझे यह प्रोडक्ट पसंद आया।": "Positive",
                    "Yeh product bahut accha hai.": "Positive", "Iski quality bilkul bekar hai.": "Negative", "Mujhe yeh product bahut pasand aaya.": "Positive"}
        for text, label in expected.items():
            self.assertEqual(analyze_sentiment(text)["label"], label, text)

    def test_negation_in_three_languages(self):
        self.assertEqual(analyze_sentiment("Not good at all")["label"], "Negative")
        self.assertEqual(analyze_sentiment("Yeh accha nahi hai")["label"], "Negative")
        self.assertEqual(analyze_sentiment("यह अच्छा नहीं है")["label"], "Negative")
        self.assertEqual(analyze_sentiment("not bad")["label"], "Positive")

    def test_mixed_and_neutral(self):
        self.assertEqual(analyze_sentiment("The fabric is good but the stitching is bad")["label"], "Mixed")
        n = analyze_sentiment("It arrived on Tuesday in a brown box")
        self.assertEqual((n["label"], n["score"]), ("Neutral", 0.0))

    def test_says_it_is_a_lexicon(self):
        self.assertIn("lexicon", analyze_sentiment("good")["method"])


if __name__ == "__main__":
    unittest.main()
